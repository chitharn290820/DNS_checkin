<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';

$errors = [];
$old = ['full_name' => '', 'email' => '', 'phone' => '', 'organization' => '', 'p_type' => 'นักศึกษา'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = $_POST['act'] ?? '';

    // ---- ตรวจ QR ของฉัน ----
    if ($act === 'lookup') {
        if (!rate_limit('lookup', 10, 3600)) { $errors[] = 'ค้นหาบ่อยเกินไป กรุณารอสักครู่'; }
        else {
            $em = mb_strtolower(trim((string)($_POST['email'] ?? '')));
            $ph = trim((string)($_POST['phone'] ?? ''));
            if (detect_threat($em . $ph)) { log_security('threat_lookup', $em); $errors[] = 'ข้อมูลไม่ปลอดภัย ถูกปฏิเสธ'; }
            else {
                $st = db()->prepare('SELECT ticket_code FROM participants WHERE email=? AND phone=?');
                $st->execute([$em, $ph]);
                if ($t = $st->fetchColumn()) { header('Location: my_qr.php?t=' . $t); exit; }
                $errors[] = 'ไม่พบข้อมูลการลงทะเบียน (ตรวจสอบอีเมลและเบอร์โทรอีกครั้ง)';
            }
        }
    }

    // ---- สมัครเข้าร่วมงาน ----
    if ($act === 'register') {
        if (!empty($_POST['website'])) { log_security('honeypot', 'bot register'); exit; }  // honeypot
        if (!rate_limit('register', 5, 3600)) { $errors[] = 'ส่งข้อมูลบ่อยเกินไป กรุณาลองใหม่ภายหลัง'; }
        else {
            $raw = [];
            foreach (['full_name', 'email', 'phone', 'organization', 'p_type'] as $f) $raw[$f] = (string)($_POST[$f] ?? '');
            foreach ($raw as $f => $v) {
                if ($th = detect_threat($v)) { log_security('threat_register', "$th ในช่อง $f: " . mb_substr($v, 0, 120)); $errors[] = 'ตรวจพบข้อมูลที่ไม่ปลอดภัย (' . $th . ') ระบบปฏิเสธคำขอ'; break; }
            }
            $old = [
                'full_name' => clean_text($raw['full_name'], 150), 'email' => mb_strtolower(trim($raw['email'])),
                'phone' => trim($raw['phone']), 'organization' => clean_text($raw['organization'], 150), 'p_type' => $raw['p_type'],
            ];
            if (!$errors) {
                if (mb_strlen($old['full_name']) < 3) $errors[] = 'กรุณากรอกชื่อ-นามสกุล';
                if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || strlen($old['email']) > 150) $errors[] = 'อีเมลไม่ถูกต้อง';
                if (!valid_phone($old['phone'])) $errors[] = 'เบอร์โทรไม่ถูกต้อง (ตัวเลข 9-15 หลัก)';
                if ($old['organization'] === '') $errors[] = 'กรุณากรอกหน่วยงาน/สถาบัน';
                if (!in_array($old['p_type'], P_TYPES, true)) $errors[] = 'ประเภทผู้เข้าร่วมไม่ถูกต้อง';
            }
            if (!$errors) {
                $st = db()->prepare('SELECT 1 FROM participants WHERE email=?'); $st->execute([$old['email']]);
                if ($st->fetchColumn()) $errors[] = 'อีเมลนี้ลงทะเบียนแล้ว — ใช้เมนู "ดู QR ของฉัน" ด้านล่าง';
            }
            if (!$errors) {
                $code = new_ticket();
                db()->prepare('INSERT INTO participants (ticket_code,full_name,email,phone,organization,p_type,source) VALUES (?,?,?,?,?,?,"web")')
                    ->execute([$code, $old['full_name'], $old['email'], $old['phone'], $old['organization'], $old['p_type']]);
                header('Location: my_qr.php?t=' . $code . '&new=1'); exit;
            }
        }
    }
}

$start = setting('event_start'); $end = setting('event_end');
html_head('ลงทะเบียนเข้าร่วมงาน'); brandbar(); ?>
<div class="container-xl py-4 py-lg-5">
  <section class="row align-items-center g-4 mb-5">
    <div class="col-lg-7">
      <span class="tag font-cyber mb-3"><i class="bi bi-cpu"></i> AI × CYBER SECURITY</span>
      <h1 class="hero-title display-4 mt-3"><?= e(setting('event_name')) ?></h1>
      <p class="lead text-secondary mt-3">เวทีเรียนรู้และประลองฝีมือด้านความมั่นคงปลอดภัยไซเบอร์ในยุค AI จัดโดย<?= e(DEPT_TH) ?> <?= e(FAC_TH) ?> <?= e(UNI_TH) ?></p>
      <div class="d-flex flex-wrap gap-3 mb-4">
        <div class="glass px-3 py-2"><i class="bi bi-calendar-event text-info"></i> <?= e(fmt_dt($start)) ?> – <?= e(date('H:i', strtotime($end))) ?> น.</div>
        <div class="glass px-3 py-2"><i class="bi bi-geo-alt-fill text-warning"></i> <?= e(setting('venue')) ?></div>
      </div>
      <div class="d-flex gap-2" id="cd" data-start="<?= e(date('c', strtotime($start))) ?>" data-end="<?= e(date('c', strtotime($end))) ?>">
        <div class="cd-box"><b id="cd-d">0</b><span>วัน</span></div><div class="cd-box"><b id="cd-h">0</b><span>ชั่วโมง</span></div>
        <div class="cd-box"><b id="cd-m">0</b><span>นาที</span></div><div class="cd-box"><b id="cd-s">0</b><span>วินาที</span></div>
      </div>
      <div class="small text-secondary mt-2" id="cd-label"></div>
    </div>

    <div class="col-lg-5">
      <div class="glass p-4">
        <h4 class="font-cyber mb-3"><i class="bi bi-person-plus-fill text-warning"></i> ลงทะเบียน</h4>
        <?php foreach ($errors as $er): ?><div class="alert alert-danger py-2 mb-2"><?= e($er) ?></div><?php endforeach; ?>
        <form method="post" autocomplete="off" novalidate>
          <?= csrf_field() ?><input type="hidden" name="act" value="register">
          <input type="text" name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">
          <div class="mb-2"><label class="form-label">ชื่อ-นามสกุล *</label><input class="form-control" name="full_name" maxlength="150" required value="<?= e($old['full_name']) ?>"></div>
          <div class="row g-2">
            <div class="col-sm-7 mb-2"><label class="form-label">อีเมล *</label><input type="email" class="form-control" name="email" maxlength="150" required value="<?= e($old['email']) ?>"></div>
            <div class="col-sm-5 mb-2"><label class="form-label">เบอร์โทร *</label><input class="form-control" name="phone" maxlength="15" required value="<?= e($old['phone']) ?>"></div>
          </div>
          <div class="mb-2"><label class="form-label">หน่วยงาน / สถาบัน *</label><input class="form-control" name="organization" maxlength="150" required value="<?= e($old['organization']) ?>"></div>
          <div class="mb-3"><label class="form-label">ประเภทผู้เข้าร่วม *</label>
            <select class="form-select" name="p_type"><?php foreach (P_TYPES as $t): ?><option <?= $old['p_type'] === $t ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select></div>
          <button class="btn btn-cyber w-100 py-2"><i class="bi bi-shield-check"></i> ลงทะเบียนและรับ QR Code</button>
          <div class="small text-secondary mt-2"><i class="bi bi-lock"></i> ข้อมูลผ่านการตรวจกรองภัยคุกคามก่อนบันทึก</div>
        </form>
      </div>
    </div>
  </section>

  <section class="row g-4">
    <div class="col-lg-6">
      <div class="glass p-4 h-100">
        <h5 class="font-cyber"><i class="bi bi-qr-code text-info"></i> ดู QR ของฉัน</h5>
        <p class="text-secondary small">เคยลงทะเบียนแล้ว? กรอกอีเมลและเบอร์โทรที่ใช้สมัคร</p>
        <form method="post" class="row g-2"><?= csrf_field() ?><input type="hidden" name="act" value="lookup">
          <div class="col-sm-6"><input type="email" class="form-control" name="email" placeholder="อีเมล" required></div>
          <div class="col-sm-4"><input class="form-control" name="phone" placeholder="เบอร์โทร" required></div>
          <div class="col-sm-2"><button class="btn btn-outline-cyan w-100"><i class="bi bi-search"></i></button></div>
        </form>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="glass p-4 h-100">
        <h5 class="font-cyber"><i class="bi bi-list-check text-warning"></i> ขั้นตอนวันงาน</h5>
        <ol class="mb-0 text-secondary"><li>ลงทะเบียนและบันทึก/พิมพ์ QR Code</li><li>แสดง QR ที่จุดลงทะเบียน เจ้าหน้าที่สแกน "เข้างาน" (ระบบเริ่มจับเวลา)</li><li>ก่อนกลับ แสดง QR อีกครั้งเพื่อสแกน "ออกงาน"</li></ol>
      </div>
    </div>
  </section>
  <div class="text-center mt-5 small text-secondary"><a href="admin/login.php" class="text-secondary"><i class="bi bi-person-lock"></i> เจ้าหน้าที่เข้าสู่ระบบ</a> · © <?= date('Y') + 543 ?> <?= e(DEPT_TH) ?></div>
</div>
<script>
(function(){
  const el=document.getElementById('cd'), s=new Date(el.dataset.start), e=new Date(el.dataset.end), lb=document.getElementById('cd-label');
  function t(){const n=new Date();let tgt=s,txt='เริ่มงานในอีก';
    if(n>=s&&n<e){tgt=e;txt='งานกำลังดำเนินอยู่ — สิ้นสุดในอีก';} else if(n>=e){lb.textContent='งานสิ้นสุดแล้ว';return;}
    let d=Math.max(0,Math.floor((tgt-n)/1000));lb.textContent=txt;
    document.getElementById('cd-d').textContent=Math.floor(d/86400);document.getElementById('cd-h').textContent=Math.floor(d%86400/3600);
    document.getElementById('cd-m').textContent=Math.floor(d%3600/60);document.getElementById('cd-s').textContent=d%60;}
  t();setInterval(t,1000);
})();
</script>
<?php html_foot();
