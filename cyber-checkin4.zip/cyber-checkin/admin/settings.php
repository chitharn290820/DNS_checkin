<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
require_admin();
$pdo = db(); $msg = ''; $err = ''; $isAdmin = ($_SESSION['admin']['role'] ?? '') === 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify(); $act = $_POST['act'] ?? '';
    try {
        if ($act === 'event') {
            require_role_admin();
            $set = [];
            foreach (['event_name' => 150, 'venue' => 150] as $k => $mx) {
                $v = (string)($_POST[$k] ?? ''); if ($th = detect_threat($v)) { log_security('threat_settings', "$th ใน $k"); throw new Exception('ข้อมูลไม่ปลอดภัย'); }
                $set[$k] = clean_text($v, $mx); if ($set[$k] === '') throw new Exception('กรุณากรอกข้อมูลให้ครบ');
            }
            foreach (['event_start', 'event_end'] as $k) {
                $ts = strtotime(str_replace('T', ' ', (string)($_POST[$k] ?? ''))); if (!$ts) throw new Exception('รูปแบบวันเวลาไม่ถูกต้อง'); $set[$k] = date('Y-m-d H:i:s', $ts);
            }
            if (strtotime($set['event_end']) <= strtotime($set['event_start'])) throw new Exception('เวลาสิ้นสุดต้องหลังเวลาเริ่ม');
            $set['late_grace_min'] = (string)max(0, min(600, (int)($_POST['late_grace_min'] ?? 30)));
            $set['scan_cooldown_sec'] = (string)max(0, min(120, (int)($_POST['scan_cooldown_sec'] ?? 10)));
            $st = $pdo->prepare('INSERT INTO settings (k,v) VALUES (?,?) ON DUPLICATE KEY UPDATE v=VALUES(v)');
            foreach ($set as $k => $v) $st->execute([$k, $v]);
            $msg = 'บันทึกการตั้งค่างานแล้ว';
        } elseif ($act === 'pw') {
            $cur = (string)($_POST['cur'] ?? ''); $new = (string)($_POST['new'] ?? ''); $new2 = (string)($_POST['new2'] ?? '');
            $st = $pdo->prepare('SELECT password_hash FROM admins WHERE id=?'); $st->execute([$_SESSION['admin']['id']]);
            if (!password_verify($cur, (string)$st->fetchColumn())) throw new Exception('รหัสผ่านปัจจุบันไม่ถูกต้อง');
            if ($new !== $new2) throw new Exception('รหัสผ่านใหม่ไม่ตรงกัน');
            if (strlen($new) < 10 || !preg_match('/[A-Za-z]/', $new) || !preg_match('/\d/', $new)) throw new Exception('รหัสผ่านใหม่ต้องยาว ≥ 10 ตัว และมีทั้งตัวอักษรและตัวเลข');
            $pdo->prepare('UPDATE admins SET password_hash=? WHERE id=?')->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['admin']['id']]);
            log_security('password_changed', $_SESSION['admin']['username']); $msg = 'เปลี่ยนรหัสผ่านแล้ว';
        } elseif ($act === 'addstaff') {
            require_role_admin();
            $u = (string)($_POST['username'] ?? ''); $n = (string)($_POST['full_name'] ?? ''); $pw = (string)($_POST['password'] ?? ''); $role = ($_POST['role'] ?? '') === 'admin' ? 'admin' : 'staff';
            if (detect_threat($u . $n)) { log_security('threat_settings', 'addstaff'); throw new Exception('ข้อมูลไม่ปลอดภัย'); }
            if (!preg_match('/^[A-Za-z0-9_.]{4,30}$/', $u)) throw new Exception('ชื่อผู้ใช้ใช้ได้เฉพาะ A-Z 0-9 _ . (4-30 ตัว)');
            if (strlen($pw) < 10 || !preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) throw new Exception('รหัสผ่านต้องยาว ≥ 10 ตัว และมีทั้งตัวอักษรและตัวเลข');
            $n = clean_text($n, 120); if ($n === '') throw new Exception('กรุณากรอกชื่อเจ้าหน้าที่');
            $pdo->prepare('INSERT INTO admins (username,password_hash,full_name,role) VALUES (?,?,?,?)')->execute([$u, password_hash($pw, PASSWORD_DEFAULT), $n, $role]); $msg = 'เพิ่มเจ้าหน้าที่แล้ว';
        } elseif ($act === 'delstaff') {
            require_role_admin(); $id = (int)($_POST['id'] ?? 0);
            if ($id === (int)$_SESSION['admin']['id']) throw new Exception('ลบบัญชีตัวเองไม่ได้');
            $pdo->prepare('DELETE FROM admins WHERE id=?')->execute([$id]); $msg = 'ลบเจ้าหน้าที่แล้ว';
        }
    } catch (PDOException $ex) { $err = $ex->getCode() === '23000' ? 'ชื่อผู้ใช้นี้มีอยู่แล้ว' : 'ข้อผิดพลาดฐานข้อมูล'; }
    catch (Exception $ex) { $err = $ex->getMessage(); }
}
$dt = fn($k) => date('Y-m-d\TH:i', strtotime(setting($k)));
$staff = $pdo->query('SELECT id,username,full_name,role,last_login FROM admins ORDER BY id')->fetchAll();
admin_head('ตั้งค่า', 'settings'); ?>
<h3 class="font-cyber mb-3"><i class="bi bi-gear-fill text-info"></i> ตั้งค่า / บัญชี</h3>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
<div class="row g-3">
  <?php if ($isAdmin): ?>
  <div class="col-lg-7"><div class="glass p-4"><h5 class="mb-3">ข้อมูลงานและการจับเวลา</h5>
    <form method="post" class="row g-2"><?= csrf_field() ?><input type="hidden" name="act" value="event">
      <div class="col-12"><label class="form-label">ชื่องาน</label><input class="form-control" name="event_name" value="<?= e(setting('event_name')) ?>" maxlength="150" required></div>
      <div class="col-12"><label class="form-label">สถานที่</label><input class="form-control" name="venue" value="<?= e(setting('venue')) ?>" maxlength="150" required></div>
      <div class="col-md-6"><label class="form-label">เริ่มงาน</label><input type="datetime-local" class="form-control" name="event_start" value="<?= e($dt('event_start')) ?>" required></div>
      <div class="col-md-6"><label class="form-label">สิ้นสุดงาน</label><input type="datetime-local" class="form-control" name="event_end" value="<?= e($dt('event_end')) ?>" required></div>
      <div class="col-md-6"><label class="form-label">ผ่อนผันมาสาย (นาทีหลังเริ่มงาน)</label><input type="number" class="form-control" name="late_grace_min" value="<?= e(setting('late_grace_min', '30')) ?>" min="0" max="600"></div>
      <div class="col-md-6"><label class="form-label">กันสแกนซ้ำ (วินาที)</label><input type="number" class="form-control" name="scan_cooldown_sec" value="<?= e(setting('scan_cooldown_sec', '10')) ?>" min="0" max="120"></div>
      <div class="col-12"><button class="btn btn-cyber">บันทึก</button></div>
    </form></div></div>
  <?php endif; ?>
  <div class="col-lg-5"><div class="glass p-4"><h5 class="mb-3">เปลี่ยนรหัสผ่านของฉัน</h5>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="act" value="pw">
      <input type="password" class="form-control mb-2" name="cur" placeholder="รหัสผ่านปัจจุบัน" required>
      <input type="password" class="form-control mb-2" name="new" placeholder="รหัสผ่านใหม่ (≥10 ตัว มีตัวอักษร+ตัวเลข)" required>
      <input type="password" class="form-control mb-3" name="new2" placeholder="ยืนยันรหัสผ่านใหม่" required>
      <button class="btn btn-outline-cyan">เปลี่ยนรหัสผ่าน</button></form></div></div>
  <?php if ($isAdmin): ?>
  <div class="col-12"><div class="glass p-4"><h5 class="mb-3">เจ้าหน้าที่</h5>
    <div class="table-responsive mb-3"><table class="table table-sm align-middle"><thead><tr><th>ผู้ใช้</th><th>ชื่อ</th><th>สิทธิ์</th><th>เข้าล่าสุด</th><th></th></tr></thead><tbody>
    <?php foreach ($staff as $s): ?><tr><td><?= e($s['username']) ?></td><td><?= e($s['full_name']) ?></td><td><span class="badge bg-<?= $s['role'] === 'admin' ? 'danger' : 'info text-dark' ?>"><?= e($s['role']) ?></span></td><td><?= e(fmt_dt($s['last_login'])) ?></td>
      <td><?php if ((int)$s['id'] !== (int)$_SESSION['admin']['id']): ?><form method="post" onsubmit="return confirm('ลบเจ้าหน้าที่นี้?')" class="m-0"><?= csrf_field() ?><input type="hidden" name="act" value="delstaff"><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div>
    <form method="post" class="row g-2"><?= csrf_field() ?><input type="hidden" name="act" value="addstaff">
      <div class="col-md-3"><input class="form-control" name="username" placeholder="ชื่อผู้ใช้" required></div>
      <div class="col-md-3"><input class="form-control" name="full_name" placeholder="ชื่อ-นามสกุล" required></div>
      <div class="col-md-3"><input type="password" class="form-control" name="password" placeholder="รหัสผ่าน ≥10 ตัว" required></div>
      <div class="col-md-2"><select class="form-select" name="role"><option value="staff">staff (สแกน/ดูข้อมูล)</option><option value="admin">admin</option></select></div>
      <div class="col-md-1"><button class="btn btn-cyber w-100"><i class="bi bi-plus-lg"></i></button></div>
    </form></div></div>
  <?php endif; ?>
</div>
<?php admin_foot(); ?>
