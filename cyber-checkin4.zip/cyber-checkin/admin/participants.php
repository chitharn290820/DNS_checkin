<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
require_admin();
$pdo = db(); $msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = $_POST['act'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    try {
        if ($act === 'save') {
            $f = [];
            foreach (['full_name', 'email', 'phone', 'organization', 'p_type'] as $k) {
                $v = (string)($_POST[$k] ?? '');
                if ($th = detect_threat($v)) { log_security('threat_admin_form', "$th ในช่อง $k"); throw new Exception('ตรวจพบข้อมูลไม่ปลอดภัย (' . $th . ')'); }
                $f[$k] = $v;
            }
            $f['full_name'] = clean_text($f['full_name']); $f['organization'] = clean_text($f['organization']);
            $f['email'] = mb_strtolower(trim($f['email'])); $f['phone'] = trim($f['phone']);
            if (mb_strlen($f['full_name']) < 3 || !filter_var($f['email'], FILTER_VALIDATE_EMAIL) || !valid_phone($f['phone']) || $f['organization'] === '' || !in_array($f['p_type'], P_TYPES, true))
                throw new Exception('ข้อมูลไม่ครบหรือรูปแบบไม่ถูกต้อง');
            if ($id) {
                $pdo->prepare('UPDATE participants SET full_name=?,email=?,phone=?,organization=?,p_type=? WHERE id=?')->execute([$f['full_name'], $f['email'], $f['phone'], $f['organization'], $f['p_type'], $id]);
                $msg = 'แก้ไขข้อมูลแล้ว';
            } else {
                $pdo->prepare('INSERT INTO participants (ticket_code,full_name,email,phone,organization,p_type,source) VALUES (?,?,?,?,?,?,"admin")')->execute([new_ticket(), $f['full_name'], $f['email'], $f['phone'], $f['organization'], $f['p_type']]);
                $msg = 'เพิ่มผู้ลงทะเบียนแล้ว';
            }
        } elseif ($act === 'toggle') {
            $pdo->prepare("UPDATE participants SET status=IF(status='registered','cancelled','registered') WHERE id=?")->execute([$id]); $msg = 'เปลี่ยนสถานะสิทธิ์แล้ว';
        } elseif ($act === 'reset') {
            $pdo->prepare('UPDATE participants SET checkin_at=NULL,checkout_at=NULL,duration_sec=NULL,is_late=0,checkin_by=NULL WHERE id=?')->execute([$id]);
            $pdo->prepare('DELETE FROM checkin_logs WHERE participant_id=?')->execute([$id]); $msg = 'รีเซ็ตการเช็คอินแล้ว';
        } elseif ($act === 'manual_in') {
            $st = $pdo->prepare('SELECT * FROM participants WHERE id=? AND status="registered" AND checkin_at IS NULL'); $st->execute([$id]);
            if ($p = $st->fetch()) {
                $n = now(); $late = time() > strtotime(setting('event_start')) + (int)setting('late_grace_min', '30') * 60 ? 1 : 0;
                $pdo->prepare('UPDATE participants SET checkin_at=?,is_late=?,checkin_by=? WHERE id=?')->execute([$n, $late, $_SESSION['admin']['id'], $id]);
                $pdo->prepare("INSERT INTO checkin_logs (participant_id,action,scanned_at,admin_id,method,ip) VALUES (?,'in',?,?,'manual',?)")->execute([$id, $n, $_SESSION['admin']['id'], client_ip()]);
                $msg = 'เช็คอินแบบ manual แล้ว';
            }
        } elseif ($act === 'delete') {
            require_role_admin();
            $pdo->prepare('DELETE FROM participants WHERE id=?')->execute([$id]); $msg = 'ลบข้อมูลแล้ว';
        }
    } catch (PDOException $ex) { $err = $ex->getCode() === '23000' ? 'อีเมลนี้มีอยู่ในระบบแล้ว' : 'เกิดข้อผิดพลาดฐานข้อมูล'; }
    catch (Exception $ex) { $err = $ex->getMessage(); }
}

$q = clean_text($_GET['q'] ?? '', 60);
$flt = in_array($_GET['f'] ?? '', ['absent', 'inside', 'out', 'cancelled', 'late'], true) ? $_GET['f'] : '';
$page = max(1, (int)($_GET['p'] ?? 1)); $per = 25;
$w = ['1=1']; $args = [];
if ($q !== '') { $w[] = '(full_name LIKE ? OR email LIKE ? OR organization LIKE ? OR ticket_code LIKE ? OR phone LIKE ?)'; $l = '%' . addcslashes($q, '%_\\') . '%'; array_push($args, $l, $l, $l, $l, $l); }
$map = ['absent' => "status='registered' AND checkin_at IS NULL", 'inside' => 'checkin_at IS NOT NULL AND checkout_at IS NULL', 'out' => 'checkout_at IS NOT NULL', 'cancelled' => "status='cancelled'", 'late' => 'is_late=1'];
if ($flt) $w[] = $map[$flt];
$where = implode(' AND ', $w);
$st = $pdo->prepare("SELECT COUNT(*) FROM participants WHERE $where"); $st->execute($args); $total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / $per)); $page = min($page, $pages);
$st = $pdo->prepare("SELECT * FROM participants WHERE $where ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per)); $st->execute($args); $rows = $st->fetchAll();
$qs = fn(array $o = []) => http_build_query(array_merge(['q' => $q, 'f' => $flt, 'p' => $page], $o));

admin_head('ผู้ลงทะเบียน', 'participants'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
  <h3 class="font-cyber mb-0"><i class="bi bi-people-fill text-info"></i> ผู้ลงทะเบียน <small class="text-secondary fs-6">(<?= number_format($total) ?> รายการ)</small></h3>
  <button class="btn btn-cyber" data-bs-toggle="modal" data-bs-target="#fm" onclick="openForm()"><i class="bi bi-plus-lg"></i> เพิ่มผู้ลงทะเบียน</button>
</div>
<?php if ($msg): ?><div class="alert alert-success py-2"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>

<form class="glass p-3 mb-3 row g-2 no-print" method="get">
  <div class="col-md-6"><input class="form-control" name="q" value="<?= e($q) ?>" placeholder="ค้นหา ชื่อ / อีเมล / หน่วยงาน / เบอร์ / รหัสบัตร"></div>
  <div class="col-md-4"><select class="form-select" name="f"><option value="">ทุกสถานะ</option>
    <?php foreach (['absent' => 'ยังไม่มา', 'inside' => 'อยู่ในงาน', 'out' => 'ออกงานแล้ว', 'late' => 'มาสาย', 'cancelled' => 'ยกเลิกสิทธิ์'] as $k => $v): ?><option value="<?= $k ?>" <?= $flt === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?></select></div>
  <div class="col-md-2"><button class="btn btn-outline-cyan w-100"><i class="bi bi-search"></i> ค้นหา</button></div>
</form>

<div class="glass p-2"><div class="table-responsive"><table class="table table-hover table-sm align-middle mb-0">
<thead><tr><th>#</th><th>ชื่อ</th><th>หน่วยงาน</th><th>ประเภท</th><th>เข้า</th><th>ออก</th><th>ระยะเวลา</th><th>สถานะ</th><th class="no-print"></th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
<tr>
  <td class="text-secondary"><?= (int)$r['id'] ?></td>
  <td><div class="fw-semibold"><?= e($r['full_name']) ?></div><small class="text-secondary"><?= e($r['email']) ?> · <?= e($r['phone']) ?></small></td>
  <td><?= e($r['organization']) ?></td><td><?= e($r['p_type']) ?></td>
  <td><?= e(fmt_dt($r['checkin_at'])) ?><?= $r['is_late'] ? ' <span class="badge bg-danger">สาย</span>' : '' ?></td>
  <td><?= e(fmt_dt($r['checkout_at'])) ?></td>
  <td><?= e(fmt_duration($r['duration_sec'] !== null ? (int)$r['duration_sec'] : null)) ?></td>
  <td><?php if ($r['status'] === 'cancelled'): ?><span class="badge bg-danger">ยกเลิก</span>
      <?php elseif ($r['checkout_at']): ?><span class="badge bg-secondary">ออกแล้ว</span>
      <?php elseif ($r['checkin_at']): ?><span class="badge bg-success">อยู่ในงาน</span>
      <?php else: ?><span class="badge bg-dark border border-secondary">ยังไม่มา</span><?php endif; ?></td>
  <td class="text-nowrap no-print">
    <a class="btn btn-sm btn-outline-info" target="_blank" href="../my_qr.php?t=<?= e($r['ticket_code']) ?>" title="ดู QR"><i class="bi bi-qr-code"></i></a>
    <button class="btn btn-sm btn-outline-warning" title="แก้ไข" data-bs-toggle="modal" data-bs-target="#fm" onclick='openForm(<?= json_encode(["id" => (int)$r["id"], "full_name" => $r["full_name"], "email" => $r["email"], "phone" => $r["phone"], "organization" => $r["organization"], "p_type" => $r["p_type"]], JSON_HEX_APOS | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_QUOT) ?>)'><i class="bi bi-pencil"></i></button>
    <div class="btn-group">
      <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></button>
      <ul class="dropdown-menu dropdown-menu-end">
        <?php foreach ([['manual_in', 'เช็คอินด้วยมือ', $r['checkin_at'] === null && $r['status'] === 'registered'], ['toggle', $r['status'] === 'cancelled' ? 'คืนสิทธิ์' : 'ยกเลิกสิทธิ์', true], ['reset', 'รีเซ็ตเวลาเข้า-ออก', $r['checkin_at'] !== null]] as [$a, $lb, $show]): if (!$show) continue; ?>
          <li><form method="post" class="m-0"><?= csrf_field() ?><input type="hidden" name="act" value="<?= $a ?>"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="dropdown-item"><?= $lb ?></button></form></li>
        <?php endforeach; ?>
        <?php if (($_SESSION['admin']['role'] ?? '') === 'admin'): ?><li><form method="post" class="m-0" onsubmit="return confirm('ลบข้อมูลนี้ถาวร?')"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="dropdown-item text-danger">ลบถาวร</button></form></li><?php endif; ?>
      </ul>
    </div>
  </td>
</tr>
<?php endforeach; if (!$rows): ?><tr><td colspan="9" class="text-center text-secondary py-4">ไม่พบข้อมูล</td></tr><?php endif; ?>
</tbody></table></div></div>

<nav class="mt-3 no-print"><ul class="pagination pagination-sm justify-content-center flex-wrap">
<?php for ($i = max(1, $page - 4); $i <= min($pages, $page + 4); $i++): ?><li class="page-item <?= $i === $page ? 'active' : '' ?>"><a class="page-link" href="?<?= e($qs(['p' => $i])) ?>"><?= $i ?></a></li><?php endfor; ?>
</ul></nav>

<div class="modal fade" id="fm" tabindex="-1"><div class="modal-dialog"><form method="post" class="modal-content"><?= csrf_field() ?>
  <input type="hidden" name="act" value="save"><input type="hidden" name="id" id="f-id" value="0">
  <div class="modal-header"><h5 class="modal-title" id="f-title">เพิ่มผู้ลงทะเบียน</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
    <div class="mb-2"><label class="form-label">ชื่อ-นามสกุล</label><input class="form-control" name="full_name" id="f-full_name" maxlength="150" required></div>
    <div class="row g-2 mb-2"><div class="col-7"><label class="form-label">อีเมล</label><input type="email" class="form-control" name="email" id="f-email" maxlength="150" required></div>
      <div class="col-5"><label class="form-label">เบอร์โทร</label><input class="form-control" name="phone" id="f-phone" maxlength="15" required></div></div>
    <div class="mb-2"><label class="form-label">หน่วยงาน</label><input class="form-control" name="organization" id="f-organization" maxlength="150" required></div>
    <div><label class="form-label">ประเภท</label><select class="form-select" name="p_type" id="f-p_type"><?php foreach (P_TYPES as $t): ?><option><?= e($t) ?></option><?php endforeach; ?></select></div>
  </div>
  <div class="modal-footer"><button class="btn btn-cyber">บันทึก</button></div>
</form></div></div>
<?php admin_foot('<script>
function openForm(d){d=d||{id:0,full_name:"",email:"",phone:"",organization:"",p_type:"นักศึกษา"};
 document.getElementById("f-title").textContent=d.id?"แก้ไขข้อมูล":"เพิ่มผู้ลงทะเบียน";
 ["id","full_name","email","phone","organization","p_type"].forEach(k=>document.getElementById("f-"+k).value=d[k]);}
</script>'); ?>
