<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
if (is_admin()) { header('Location: index.php'); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $u = trim((string)($_POST['username'] ?? '')); $pw = (string)($_POST['password'] ?? '');
    if (detect_threat($u)) { log_security('threat_login', mb_substr($u, 0, 120)); $err = 'ตรวจพบข้อมูลไม่ปลอดภัย'; }
    else {
        // ล็อกเมื่อผิดเกิน 5 ครั้งใน 15 นาที (ตาม IP)
        $st = db()->prepare("SELECT COUNT(*) FROM security_logs WHERE event_type='login_fail' AND ip=? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
        $st->execute([client_ip()]);
        if ((int)$st->fetchColumn() >= 5) { $err = 'ล็อกอินผิดหลายครั้ง ถูกล็อกชั่วคราว 15 นาที'; log_security('login_locked', $u); }
        else {
            $st = db()->prepare('SELECT * FROM admins WHERE username=?'); $st->execute([$u]); $a = $st->fetch();
            if ($a && password_verify($pw, $a['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['admin'] = ['id' => (int)$a['id'], 'username' => $a['username'], 'full_name' => $a['full_name'], 'role' => $a['role']];
                $_SESSION['ua'] = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? ''); $_SESSION['last_act'] = time();
                db()->prepare('UPDATE admins SET last_login=? WHERE id=?')->execute([now(), $a['id']]);
                log_security('login_ok', $a['username']);
                header('Location: index.php'); exit;
            }
            log_security('login_fail', mb_substr($u, 0, 60)); $err = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
        }
    }
}
html_head('เข้าสู่ระบบเจ้าหน้าที่', '../'); brandbar('../'); ?>
<div class="container py-5" style="max-width:460px">
  <div class="glass p-4">
    <div class="text-center mb-3"><span class="tag font-cyber"><i class="bi bi-shield-lock"></i> STAFF ACCESS</span>
      <h3 class="font-cyber mt-3">เข้าสู่ระบบหลังบ้าน</h3><div class="text-secondary small"><?= e(setting('event_name')) ?></div></div>
    <?php if ($err): ?><div class="alert alert-danger py-2"><?= e($err) ?></div><?php endif; ?>
    <form method="post" autocomplete="off"><?= csrf_field() ?>
      <div class="mb-3"><label class="form-label">ชื่อผู้ใช้</label><div class="input-group"><span class="input-group-text bg-transparent text-info border-secondary"><i class="bi bi-person"></i></span><input class="form-control" name="username" maxlength="50" required autofocus></div></div>
      <div class="mb-3"><label class="form-label">รหัสผ่าน</label><div class="input-group"><span class="input-group-text bg-transparent text-info border-secondary"><i class="bi bi-key"></i></span><input type="password" class="form-control" name="password" required></div></div>
      <button class="btn btn-cyber w-100 py-2"><i class="bi bi-box-arrow-in-right"></i> เข้าสู่ระบบ</button>
    </form>
    <div class="text-center mt-3"><a href="../index.php" class="small text-secondary">← กลับหน้าบ้าน</a></div>
  </div>
</div>
<?php html_foot('', '../');
