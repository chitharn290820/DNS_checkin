<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
require_admin();

// ดาวน์โหลดไฟล์ตัวอย่าง
if (isset($_GET['template'])) {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="template_participants.csv"');
    echo "\xEF\xBB\xBF" . "full_name,email,phone,organization,p_type\nสมชาย ใจดี,somchai@example.com,0812345678,มจพ.,นักศึกษา\n"; exit;
}

$report = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $f = $_FILES['csv'] ?? null; $problem = '';
    if (!$f || $f['error'] !== UPLOAD_ERR_OK) $problem = 'อัปโหลดไฟล์ไม่สำเร็จ';
    elseif ($f['size'] > 2 * 1024 * 1024) $problem = 'ไฟล์ใหญ่เกิน 2MB';
    elseif (strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'csv') $problem = 'รองรับเฉพาะไฟล์ .csv';
    else {
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        if (!in_array($mime, ['text/plain', 'text/csv', 'application/csv', 'application/vnd.ms-excel'], true)) { $problem = 'ชนิดไฟล์ไม่ถูกต้อง (' . $mime . ')'; log_security('threat_upload', 'mime ' . $mime . ' name ' . mb_substr($f['name'], 0, 80)); }
    }
    if ($problem) { $report = ['error' => $problem]; }
    else {
        $h = fopen($f['tmp_name'], 'r'); $first = fgets($h);
        if ($first === false) { $report = ['error' => 'ไฟล์ว่าง']; }
        else {
            $first = preg_replace('/^\xEF\xBB\xBF/', '', $first);
            if (!mb_check_encoding($first, 'UTF-8')) { $report = ['error' => 'ไฟล์ต้องเป็น UTF-8 (ใน Excel เลือก Save as CSV UTF-8)']; }
            else {
                $head = array_map(fn($x) => strtolower(trim($x)), str_getcsv($first));
                $need = ['full_name', 'email', 'phone', 'organization'];
                if (array_diff($need, $head)) { $report = ['error' => 'หัวคอลัมน์ไม่ครบ ต้องมี: full_name, email, phone, organization (p_type ไม่บังคับ)']; }
                else {
                    $idx = array_flip($head); $ok = 0; $dup = 0; $bad = []; $line = 1; $seen = [];
                    $ins = db()->prepare('INSERT INTO participants (ticket_code,full_name,email,phone,organization,p_type,source) VALUES (?,?,?,?,?,?,"import")');
                    $chk = db()->prepare('SELECT 1 FROM participants WHERE email=?');
                    while (($row = fgetcsv($h)) !== false && $line < 5001) {
                        $line++;
                        if (count($row) === 1 && trim((string)$row[0]) === '') continue;
                        $g = fn($k) => (string)($row[$idx[$k] ?? -1] ?? '');
                        $vals = ['full_name' => $g('full_name'), 'email' => $g('email'), 'phone' => $g('phone'), 'organization' => $g('organization'), 'p_type' => $g('p_type') ?: 'นักศึกษา'];
                        // 1) กรองภัยคุกคาม
                        foreach ($vals as $k => $v) {
                            if ($th = detect_threat($v)) { $bad[] = [$line, "ตรวจพบ $th ในช่อง $k"]; log_security('threat_import', "บรรทัด $line $th ($k): " . mb_substr($v, 0, 100)); continue 2; }
                        }
                        // 2) ทำความสะอาด + ตรวจรูปแบบ
                        $n = clean_text($vals['full_name']); $em = mb_strtolower(trim($vals['email'])); $ph = preg_replace('/[^0-9+\- ]/', '', $vals['phone']); $og = clean_text($vals['organization']);
                        $pt = in_array(trim($vals['p_type']), P_TYPES, true) ? trim($vals['p_type']) : 'นักศึกษา';
                        if (mb_strlen($n) < 3) { $bad[] = [$line, 'ชื่อไม่ถูกต้อง']; continue; }
                        if (!filter_var($em, FILTER_VALIDATE_EMAIL) || strlen($em) > 150) { $bad[] = [$line, 'อีเมลไม่ถูกต้อง']; continue; }
                        if (!valid_phone($ph)) { $bad[] = [$line, 'เบอร์โทรไม่ถูกต้อง']; continue; }
                        if ($og === '') { $bad[] = [$line, 'ไม่มีหน่วยงาน']; continue; }
                        // 3) ซ้ำ
                        $chk->execute([$em]);
                        if (isset($seen[$em]) || $chk->fetchColumn()) { $dup++; continue; }
                        $seen[$em] = 1;
                        $ins->execute([new_ticket(), $n, $em, $ph, $og, $pt]); $ok++;
                    }
                    $report = ['ok' => $ok, 'dup' => $dup, 'bad' => $bad, 'lines' => $line - 1];
                    log_security('import_done', "นำเข้า $ok ซ้ำ $dup ปฏิเสธ " . count($bad));
                }
            }
        }
        fclose($h);
    }
}
admin_head('นำเข้าข้อมูล', 'import'); ?>
<h3 class="font-cyber mb-3"><i class="bi bi-cloud-upload text-info"></i> นำเข้ารายชื่อ (CSV) <small class="fs-6 text-secondary">พร้อมตัวกรองภัยคุกคาม</small></h3>
<div class="row g-3">
  <div class="col-lg-5"><div class="glass p-4">
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?>
      <label class="form-label">เลือกไฟล์ .csv (UTF-8, ไม่เกิน 2MB / 5,000 แถว)</label>
      <input type="file" class="form-control mb-3" name="csv" accept=".csv,text/csv" required>
      <button class="btn btn-cyber"><i class="bi bi-shield-check"></i> ตรวจและนำเข้า</button>
      <a class="btn btn-outline-cyan" href="?template=1"><i class="bi bi-download"></i> ไฟล์ตัวอย่าง</a>
    </form>
    <hr style="border-color:var(--line)">
    <div class="small text-secondary"><b class="text-info">ระบบตรวจอะไรบ้าง</b><ul class="mb-0 mt-1">
      <li>ชนิดไฟล์/นามสกุล/ขนาด และการเข้ารหัส UTF-8</li><li>XSS, SQL Injection, Code Injection, Path Traversal, Null byte ในทุกช่อง</li>
      <li>ตัด HTML tag และอักขระนำสูตร Excel (<code>= + - @</code>) กัน CSV Injection</li><li>ตรวจอีเมล/เบอร์โทร และตัดรายการซ้ำ</li><li>บันทึกเหตุการณ์ที่ถูกบล็อกลงหน้า "ประวัติ / ความปลอดภัย"</li></ul></div>
  </div></div>
  <div class="col-lg-7"><div class="glass p-4">
    <h5>ผลการนำเข้า</h5>
    <?php if (!$report): ?><div class="text-secondary">ยังไม่มีการนำเข้า</div>
    <?php elseif (isset($report['error'])): ?><div class="alert alert-danger"><?= e($report['error']) ?></div>
    <?php else: ?>
      <div class="row text-center g-2 mb-3">
        <div class="col"><div class="glass p-2"><div class="fs-3 font-cyber text-success"><?= $report['ok'] ?></div>นำเข้าสำเร็จ</div></div>
        <div class="col"><div class="glass p-2"><div class="fs-3 font-cyber text-warning"><?= $report['dup'] ?></div>ซ้ำ (ข้าม)</div></div>
        <div class="col"><div class="glass p-2"><div class="fs-3 font-cyber text-danger"><?= count($report['bad']) ?></div>ถูกปฏิเสธ</div></div>
      </div>
      <?php if ($report['bad']): ?><div class="table-responsive" style="max-height:320px"><table class="table table-sm"><thead><tr><th>บรรทัด</th><th>เหตุผล</th></tr></thead><tbody>
        <?php foreach (array_slice($report['bad'], 0, 200) as [$ln, $why]): ?><tr><td><?= (int)$ln ?></td><td><?= e($why) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
    <?php endif; ?>
  </div></div>
</div>
<?php admin_foot(); ?>
