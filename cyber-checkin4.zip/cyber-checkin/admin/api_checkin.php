<?php
require __DIR__ . '/../config.php';
require_admin(true);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_out(['ok' => false, 'msg' => 'Method not allowed'], 405);
csrf_verify(true);

$adminId = (int)$_SESSION['admin']['id'];
session_write_close(); // ปล่อย lock ของ session ไม่ให้คำขออื่นรอคิว
$mode    = in_array($_POST['mode'] ?? '', ['auto', 'in', 'out'], true) ? $_POST['mode'] : 'auto';
$method  = ($_POST['method'] ?? 'scan') === 'manual' ? 'manual' : 'scan';
$token   = strtoupper(trim((string)($_POST['token'] ?? '')));

// ----- 1) กรองข้อมูลจาก QR -----
if ($th = detect_threat($token)) { log_security('threat_qr', "$th: " . mb_substr($token, 0, 120)); json_out(['ok' => false, 'level' => 'bad', 'msg' => 'QR มีข้อมูลอันตราย ถูกบล็อก (' . $th . ')']); }
if (!preg_match('/^[A-F0-9]{20}$/', $token)) { log_security('invalid_qr', mb_substr($token, 0, 60)); json_out(['ok' => false, 'level' => 'bad', 'msg' => 'รูปแบบ QR ไม่ถูกต้อง']); }

// ----- 2) ตรวจกับฐานข้อมูลผู้สมัคร -----
$st = db()->prepare('SELECT * FROM participants WHERE ticket_code=?'); $st->execute([$token]); $p = $st->fetch();
if (!$p) { log_security('unknown_qr', $token); json_out(['ok' => false, 'level' => 'bad', 'msg' => 'ไม่พบข้อมูลในระบบ (QR ไม่ได้ลงทะเบียน)']); }

$info = ['name' => $p['full_name'], 'org' => $p['organization'], 'type' => $p['p_type']];
if ($p['status'] === 'cancelled') json_out(['ok' => false, 'level' => 'bad', 'msg' => 'สิทธิ์ถูกยกเลิก ไม่อนุญาตให้เข้างาน'] + $info);

// ----- 3) กันสแกนซ้ำรัว ๆ -----
$cool = max(0, (int)setting('scan_cooldown_sec', '10'));
$st = db()->prepare('SELECT scanned_at FROM checkin_logs WHERE participant_id=? ORDER BY id DESC LIMIT 1'); $st->execute([$p['id']]);
if (($last = $st->fetchColumn()) && (time() - strtotime($last)) < $cool && $method === 'scan') {
    json_out(['ok' => false, 'level' => 'warn', 'msg' => 'สแกนซ้ำเร็วเกินไป (รอ ' . $cool . ' วินาที)'] + $info);
}

// ----- 4) ตัดสินใจเข้า / ออก -----
$action = $mode;
if ($mode === 'auto') { $action = $p['checkin_at'] === null ? 'in' : ($p['checkout_at'] === null ? 'out' : 'done'); }
$now = now(); $nowTs = strtotime($now);

if ($action === 'done') json_out(['ok' => false, 'level' => 'warn', 'msg' => 'ผู้นี้เข้าและออกงานครบแล้ว', 'in' => fmt_dt($p['checkin_at']), 'out' => fmt_dt($p['checkout_at']), 'duration' => fmt_duration((int)$p['duration_sec'])] + $info);

if ($action === 'in') {
    if ($p['checkin_at'] !== null) json_out(['ok' => false, 'level' => 'warn', 'msg' => 'เช็คอินไปแล้วเมื่อ ' . fmt_dt($p['checkin_at'])] + $info);
    $late = $nowTs > strtotime(setting('event_start')) + ((int)setting('late_grace_min', '30')) * 60 ? 1 : 0;
    $pdo = db(); $pdo->beginTransaction();
    try {
        $u = $pdo->prepare('UPDATE participants SET checkin_at=?, checkout_at=NULL, duration_sec=NULL, is_late=?, checkin_by=? WHERE id=? AND checkin_at IS NULL');
        $u->execute([$now, $late, $adminId, $p['id']]);
        if ($u->rowCount() === 1) $pdo->prepare('INSERT INTO checkin_logs (participant_id,action,scanned_at,admin_id,method,ip) VALUES (?,?,?,?,?,?)')->execute([$p['id'], 'in', $now, $adminId, $method, client_ip()]);
        $pdo->commit();
    } catch (Throwable $e) { $pdo->rollBack(); json_out(['ok' => false, 'level' => 'bad', 'msg' => 'บันทึกไม่สำเร็จ'], 500); }
    json_out(['ok' => true, 'level' => $late ? 'warn' : 'ok', 'action' => 'in', 'msg' => $late ? 'เช็คอินสำเร็จ (มาสาย)' : 'เช็คอินสำเร็จ — เริ่มจับเวลา', 'in' => fmt_dt($now), 'late' => (bool)$late] + $info);
}

// out
if ($p['checkin_at'] === null) json_out(['ok' => false, 'level' => 'warn', 'msg' => 'ยังไม่ได้เช็คอินเข้างาน'] + $info);
if ($p['checkout_at'] !== null) json_out(['ok' => false, 'level' => 'warn', 'msg' => 'ออกงานไปแล้วเมื่อ ' . fmt_dt($p['checkout_at'])] + $info);
$dur = max(0, $nowTs - strtotime($p['checkin_at']));
$pdo = db(); $pdo->beginTransaction();
try {
    $u = $pdo->prepare('UPDATE participants SET checkout_at=?, duration_sec=? WHERE id=? AND checkout_at IS NULL');
    $u->execute([$now, $dur, $p['id']]);
    if ($u->rowCount() === 1) $pdo->prepare('INSERT INTO checkin_logs (participant_id,action,scanned_at,admin_id,method,ip) VALUES (?,?,?,?,?,?)')->execute([$p['id'], 'out', $now, $adminId, $method, client_ip()]);
    $pdo->commit();
} catch (Throwable $e) { $pdo->rollBack(); json_out(['ok' => false, 'level' => 'bad', 'msg' => 'บันทึกไม่สำเร็จ'], 500); }
json_out(['ok' => true, 'level' => 'ok', 'action' => 'out', 'msg' => 'ออกงานสำเร็จ', 'in' => fmt_dt($p['checkin_at']), 'out' => fmt_dt($now), 'duration' => fmt_duration($dur)] + $info);
