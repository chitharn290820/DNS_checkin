<?php
require __DIR__ . '/../config.php';
require_admin();
$safe = function ($v): string { $v = (string)$v; return $v !== '' && strpos("=+-@\t\r", $v[0]) !== false ? "'" . $v : $v; };
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="checkin_report_' . date('Ymd_His') . '.csv"');
$o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
fputcsv($o, ['รหัสบัตร', 'ชื่อ-นามสกุล', 'อีเมล', 'เบอร์โทร', 'หน่วยงาน', 'ประเภท', 'สถานะสิทธิ์', 'เวลาเข้า', 'เวลาออก', 'ระยะเวลาในงาน', 'ระยะเวลา(วินาที)', 'มาสาย', 'แหล่งที่มา', 'ลงทะเบียนเมื่อ']);
foreach (db()->query('SELECT * FROM participants ORDER BY id') as $r) {
    fputcsv($o, array_map($safe, [$r['ticket_code'], $r['full_name'], $r['email'], $r['phone'], $r['organization'], $r['p_type'], $r['status'] === 'registered' ? 'ปกติ' : 'ยกเลิก',
        $r['checkin_at'] ?? '', $r['checkout_at'] ?? '', $r['duration_sec'] !== null ? fmt_duration((int)$r['duration_sec']) : '', $r['duration_sec'] ?? '', $r['is_late'] ? 'สาย' : '', $r['source'], $r['created_at']]));
}
fclose($o);
