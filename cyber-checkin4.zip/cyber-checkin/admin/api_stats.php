<?php
require __DIR__ . '/../config.php';
require_admin(true);
session_write_close();
$pdo = db();
$one = fn(string $sql) => $pdo->query($sql)->fetch();
$s = $one("SELECT
  SUM(status='registered') total,
  SUM(status='registered' AND checkin_at IS NOT NULL) checked_in,
  SUM(status='registered' AND checkin_at IS NOT NULL AND checkout_at IS NULL) inside,
  SUM(status='registered' AND checkout_at IS NOT NULL) checked_out,
  SUM(status='cancelled') cancelled,
  SUM(is_late=1) late,
  AVG(duration_sec) avg_dur, MAX(duration_sec) max_dur,
  MIN(checkin_at) first_in, MAX(checkin_at) last_in FROM participants");
$total = (int)$s['total']; $ci = (int)$s['checked_in'];

$hourly = $pdo->query("SELECT DATE_FORMAT(scanned_at,'%H:00') h, SUM(action='in') ins, SUM(action='out') outs FROM checkin_logs GROUP BY h ORDER BY h")->fetchAll();
$orgs = $pdo->query("SELECT organization, COUNT(*) total, SUM(checkin_at IS NOT NULL) ci FROM participants WHERE status='registered' GROUP BY organization ORDER BY total DESC LIMIT 8")->fetchAll();
$types = $pdo->query("SELECT p_type, COUNT(*) total, SUM(checkin_at IS NOT NULL) ci FROM participants WHERE status='registered' GROUP BY p_type")->fetchAll();
$recent = $pdo->query("SELECT l.action, l.scanned_at, l.method, p.full_name, p.organization, p.duration_sec FROM checkin_logs l JOIN participants p ON p.id=l.participant_id ORDER BY l.id DESC LIMIT 10")->fetchAll();
$sec = $one("SELECT COUNT(*) c, SUM(event_type LIKE 'threat%') threats FROM security_logs WHERE created_at > (NOW() - INTERVAL 24 HOUR)");
$secRecent = $pdo->query("SELECT event_type, detail, ip, created_at FROM security_logs ORDER BY id DESC LIMIT 5")->fetchAll();
$reg7 = $pdo->query("SELECT DATE(created_at) d, COUNT(*) c FROM participants GROUP BY d ORDER BY d DESC LIMIT 7")->fetchAll();

foreach ($recent as &$r) { $r['scanned_at'] = fmt_dt($r['scanned_at']); $r['dur'] = fmt_duration($r['duration_sec'] !== null ? (int)$r['duration_sec'] : null); } unset($r);
foreach ($secRecent as &$r) { $r['created_at'] = fmt_dt($r['created_at']); } unset($r);

json_out([
  'ok' => true, 'now' => date('c'), 'event_start' => date('c', strtotime(setting('event_start'))), 'event_end' => date('c', strtotime(setting('event_end'))),
  'total' => $total, 'checked_in' => $ci, 'inside' => (int)$s['inside'], 'checked_out' => (int)$s['checked_out'],
  'absent' => max(0, $total - $ci), 'cancelled' => (int)$s['cancelled'], 'late' => (int)$s['late'],
  'pct' => $total ? round($ci * 100 / $total, 1) : 0,
  'avg_dur' => $s['avg_dur'] !== null ? fmt_duration((int)$s['avg_dur']) : '-', 'max_dur' => $s['max_dur'] !== null ? fmt_duration((int)$s['max_dur']) : '-',
  'first_in' => fmt_dt($s['first_in']), 'last_in' => fmt_dt($s['last_in']),
  'hourly' => $hourly, 'orgs' => $orgs, 'types' => $types, 'recent' => $recent,
  'sec24' => (int)$sec['c'], 'threats24' => (int)$sec['threats'], 'sec_recent' => $secRecent, 'reg7' => array_reverse($reg7),
]);
