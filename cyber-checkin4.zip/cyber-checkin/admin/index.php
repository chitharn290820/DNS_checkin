<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
require_admin();
admin_head('Dashboard', 'index'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
  <div><h3 class="font-cyber mb-0"><i class="bi bi-speedometer2 text-info"></i> DASHBOARD</h3><div class="text-secondary small"><?= e(setting('event_name')) ?></div></div>
  <div class="d-flex gap-2 no-print"><a class="btn btn-cyber" href="scan.php"><i class="bi bi-qr-code-scan"></i> เปิดหน้าสแกน</a><a class="btn btn-outline-cyan" href="export.php"><i class="bi bi-file-earmark-spreadsheet"></i> ส่งออกรายงาน</a></div>
</div>

<!-- Event timer -->
<div class="glass p-3 mb-3 d-flex flex-wrap align-items-center gap-4">
  <div><div class="small text-secondary">สถานะงาน</div><div class="fs-4 font-cyber" id="ev-state">-</div></div>
  <div><div class="small text-secondary">เวลาที่ผ่านไป (นับจากเปิดงาน)</div><div class="fs-3 font-cyber text-info" id="ev-elapsed">00:00:00</div></div>
  <div><div class="small text-secondary">เวลาที่เหลือ / ก่อนเริ่ม</div><div class="fs-3 font-cyber text-warning" id="ev-remain">00:00:00</div></div>
  <div class="flex-grow-1" style="min-width:220px"><div class="small text-secondary mb-1">ความคืบหน้าของงาน <span id="ev-pct"></span></div><div class="progress"><div class="progress-bar" id="ev-bar" style="width:0%"></div></div></div>
  <div class="small text-secondary text-end">เริ่ม <?= e(fmt_dt(setting('event_start'))) ?><br>สิ้นสุด <?= e(fmt_dt(setting('event_end'))) ?></div>
</div>

<div class="row g-3 mb-3">
  <?php foreach ([['total','ลงทะเบียนทั้งหมด','bi-people-fill','text-info'],['checked_in','เช็คอินแล้ว','bi-box-arrow-in-right','text-success'],['inside','อยู่ในงานขณะนี้','bi-geo-alt-fill','text-warning'],['checked_out','ออกงานแล้ว','bi-box-arrow-right','text-light'],['absent','ยังไม่มา','bi-hourglass-split','text-secondary'],['late','มาสาย','bi-alarm','text-danger']] as [$k,$lb,$ic,$cl]): ?>
  <div class="col-6 col-md-4 col-xl-2"><div class="glass stat"><i class="bi <?= $ic ?> bg"></i><div class="small text-secondary"><?= $lb ?></div><div class="num <?= $cl ?>" id="s-<?= $k ?>">0</div></div></div>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-4"><div class="glass p-3 h-100">
    <div class="small text-secondary">อัตราการเข้าร่วม</div><div class="font-cyber fs-1 text-success" id="s-pct">0%</div>
    <div class="progress mb-3"><div class="progress-bar" id="s-bar" style="width:0%"></div></div>
    <div class="small">เวลาอยู่ในงานเฉลี่ย: <b id="s-avg">-</b><br>นานที่สุด: <b id="s-max">-</b><br>เช็คอินคนแรก: <b id="s-first">-</b><br>เช็คอินล่าสุด: <b id="s-last">-</b><br>ยกเลิกสิทธิ์: <b id="s-cancelled">0</b> ราย</div>
  </div></div>
  <div class="col-lg-8"><div class="glass p-3 h-100"><div class="fw-semibold mb-2"><i class="bi bi-bar-chart-line text-info"></i> จำนวนเข้า-ออกงานรายชั่วโมง</div><canvas id="chHour" height="110"></canvas></div></div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-6"><div class="glass p-3 h-100"><div class="fw-semibold mb-2"><i class="bi bi-building text-warning"></i> เช็คอินแยกตามหน่วยงาน (Top 8)</div><canvas id="chOrg" height="150"></canvas></div></div>
  <div class="col-lg-3"><div class="glass p-3 h-100"><div class="fw-semibold mb-2"><i class="bi bi-pie-chart text-info"></i> ประเภทผู้เข้าร่วม</div><canvas id="chType"></canvas></div></div>
  <div class="col-lg-3"><div class="glass p-3 h-100">
    <div class="fw-semibold mb-2"><i class="bi bi-shield-exclamation text-danger"></i> ความปลอดภัย (24 ชม.)</div>
    <div class="d-flex gap-3 mb-2"><div><div class="font-cyber fs-2" id="sec-all">0</div><small class="text-secondary">เหตุการณ์</small></div><div><div class="font-cyber fs-2 text-danger" id="sec-thr">0</div><small class="text-secondary">ภัยคุกคามที่ถูกบล็อก</small></div></div>
    <ul class="list-unstyled small mb-0" id="sec-list"></ul>
  </div></div>
</div>

<div class="glass p-3">
  <div class="fw-semibold mb-2"><i class="bi bi-activity text-success"></i> การสแกนล่าสุด <span class="badge bg-success pulse ms-1">LIVE</span></div>
  <div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>เวลา</th><th>ชื่อ</th><th>หน่วยงาน</th><th>รายการ</th><th>ระยะเวลาในงาน</th></tr></thead><tbody id="recent"></tbody></table></div>
</div>

<?php admin_foot('<script src="../assets/vendor/chart/chart.umd.min.js"></script>
<script>
const $=id=>document.getElementById(id), pad=n=>String(n).padStart(2,"0");
const hms=s=>{s=Math.max(0,Math.floor(s));return pad(Math.floor(s/3600))+":"+pad(Math.floor(s%3600/60))+":"+pad(s%60)};
const esc=s=>String(s??"").replace(/[&<>"\']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[c]));
Chart.defaults.color="#8aa0c2";Chart.defaults.borderColor="rgba(0,229,255,.12)";
let charts={},ev={start:0,end:0,off:0};
function mk(id,cfg){if(charts[id]){charts[id].data=cfg.data;charts[id].update();return;}charts[id]=new Chart($(id),cfg);}
async function load(){
 try{
  const r=await fetch("api_stats.php",{cache:"no-store"});const d=await r.json();if(!d.ok)return;
  ev.start=new Date(d.event_start).getTime();ev.end=new Date(d.event_end).getTime();ev.off=new Date(d.now).getTime()-Date.now();
  ["total","checked_in","inside","checked_out","absent","late","cancelled"].forEach(k=>{if($("s-"+k))$("s-"+k).textContent=d[k]});
  $("s-pct").textContent=d.pct+"%";$("s-bar").style.width=d.pct+"%";
  $("s-avg").textContent=d.avg_dur;$("s-max").textContent=d.max_dur;$("s-first").textContent=d.first_in;$("s-last").textContent=d.last_in;
  mk("chHour",{type:"bar",data:{labels:d.hourly.map(x=>x.h),datasets:[{label:"เข้างาน",data:d.hourly.map(x=>+x.ins),backgroundColor:"#00e5ff"},{label:"ออกงาน",data:d.hourly.map(x=>+x.outs),backgroundColor:"#ff6a1a"}]},options:{plugins:{legend:{position:"bottom"}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});
  mk("chOrg",{type:"bar",data:{labels:d.orgs.map(x=>x.organization),datasets:[{label:"ลงทะเบียน",data:d.orgs.map(x=>+x.total),backgroundColor:"rgba(138,160,194,.5)"},{label:"เช็คอิน",data:d.orgs.map(x=>+x.ci),backgroundColor:"#25e08a"}]},options:{indexAxis:"y",plugins:{legend:{position:"bottom"}},scales:{x:{beginAtZero:true,ticks:{precision:0}}}}});
  mk("chType",{type:"doughnut",data:{labels:d.types.map(x=>x.p_type),datasets:[{data:d.types.map(x=>+x.total),backgroundColor:["#00e5ff","#ff6a1a","#25e08a","#ffc233","#d71920"],borderWidth:0}]},options:{plugins:{legend:{position:"bottom"}}}});
  $("sec-all").textContent=d.sec24;$("sec-thr").textContent=d.threats24;
  $("sec-list").innerHTML=d.sec_recent.map(x=>`<li class="mb-1"><span class="badge bg-dark border border-secondary">${esc(x.event_type)}</span> <span class="text-secondary">${esc(x.created_at)}</span></li>`).join("")||"<li class=text-secondary>ไม่มีเหตุการณ์</li>";
  $("recent").innerHTML=d.recent.map(x=>`<tr><td>${esc(x.scanned_at)}</td><td>${esc(x.full_name)}</td><td>${esc(x.organization)}</td><td>${x.action==="in"?"<span class=\\"badge bg-success\\">เข้างาน</span>":"<span class=\\"badge bg-warning text-dark\\">ออกงาน</span>"}${x.method==="manual"?" <span class=\\"badge bg-secondary\\">manual</span>":""}</td><td>${x.action==="out"?esc(x.dur):"-"}</td></tr>`).join("")||"<tr><td colspan=5 class=text-center text-secondary>ยังไม่มีการสแกน</td></tr>";
 }catch(e){}
}
function tick(){
 if(!ev.start)return;const n=Date.now()+ev.off;let st,el=0,rm=0;
 if(n<ev.start){st="ยังไม่เริ่ม";rm=(ev.start-n)/1000;}
 else if(n<ev.end){st="กำลังดำเนินงาน";el=(n-ev.start)/1000;rm=(ev.end-n)/1000;}
 else{st="สิ้นสุดแล้ว";el=(ev.end-ev.start)/1000;}
 const p=Math.min(100,Math.max(0,(n-ev.start)*100/(ev.end-ev.start)));
 $("ev-state").textContent=st;$("ev-elapsed").textContent=hms(el);$("ev-remain").textContent=hms(rm);$("ev-bar").style.width=p+"%";$("ev-pct").textContent=p.toFixed(0)+"%";
}
load();setInterval(load,8000);setInterval(tick,1000);
</script>'); ?>
