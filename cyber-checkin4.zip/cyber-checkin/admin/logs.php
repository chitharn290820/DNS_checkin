<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
require_admin();
$tab = ($_GET['tab'] ?? 'checkin') === 'security' ? 'security' : 'checkin';
$page = max(1, (int)($_GET['p'] ?? 1)); $per = 50;
$tbl = $tab === 'security' ? 'security_logs' : 'checkin_logs';
$total = (int)db()->query("SELECT COUNT(*) FROM $tbl")->fetchColumn(); $pages = max(1, (int)ceil($total / $per)); $page = min($page, $pages);
$off = ($page - 1) * $per;
if ($tab === 'security') $rows = db()->query("SELECT * FROM security_logs ORDER BY id DESC LIMIT $per OFFSET $off")->fetchAll();
else $rows = db()->query("SELECT l.*, p.full_name, p.organization, a.username FROM checkin_logs l JOIN participants p ON p.id=l.participant_id LEFT JOIN admins a ON a.id=l.admin_id ORDER BY l.id DESC LIMIT $per OFFSET $off")->fetchAll();
$sevColor = fn($t) => str_starts_with($t, 'threat') ? 'danger' : (in_array($t, ['login_fail', 'login_locked', 'csrf_fail', 'rate_limit', 'unknown_qr', 'invalid_qr', 'honeypot'], true) ? 'warning text-dark' : 'info text-dark');
admin_head('ประวัติ / ความปลอดภัย', 'logs'); ?>
<h3 class="font-cyber mb-3"><i class="bi bi-journal-text text-info"></i> ประวัติและความปลอดภัย</h3>
<ul class="nav nav-pills mb-3 no-print">
  <li class="nav-item"><a class="nav-link <?= $tab === 'checkin' ? 'active bg-danger' : '' ?>" href="?tab=checkin">ประวัติการสแกน</a></li>
  <li class="nav-item"><a class="nav-link <?= $tab === 'security' ? 'active bg-danger' : '' ?>" href="?tab=security">เหตุการณ์ความปลอดภัย</a></li>
</ul>
<div class="glass p-2"><div class="table-responsive"><table class="table table-sm table-hover align-middle mb-0">
<?php if ($tab === 'checkin'): ?>
<thead><tr><th>เวลา</th><th>ชื่อ</th><th>หน่วยงาน</th><th>รายการ</th><th>วิธี</th><th>เจ้าหน้าที่</th><th>IP</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e(fmt_dt($r['scanned_at'])) ?></td><td><?= e($r['full_name']) ?></td><td><?= e($r['organization']) ?></td>
<td><span class="badge bg-<?= $r['action'] === 'in' ? 'success' : 'warning text-dark' ?>"><?= $r['action'] === 'in' ? 'เข้างาน' : 'ออกงาน' ?></span></td><td><?= e($r['method']) ?></td><td><?= e($r['username'] ?? '-') ?></td><td><?= e($r['ip']) ?></td></tr><?php endforeach; ?>
<?php else: ?>
<thead><tr><th>เวลา</th><th>ประเภท</th><th>รายละเอียด</th><th>IP</th><th>User-Agent</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td class="text-nowrap"><?= e(fmt_dt($r['created_at'])) ?></td><td><span class="badge bg-<?= $sevColor($r['event_type']) ?>"><?= e($r['event_type']) ?></span></td>
<td style="max-width:420px;word-break:break-all"><?= e($r['detail']) ?></td><td><?= e($r['ip']) ?></td><td class="small text-secondary" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($r['user_agent']) ?></td></tr><?php endforeach; ?>
<?php endif; if (!$rows): ?><tr><td colspan="7" class="text-center text-secondary py-4">ไม่มีข้อมูล</td></tr><?php endif; ?>
</tbody></table></div></div>
<nav class="mt-3"><ul class="pagination pagination-sm justify-content-center flex-wrap">
<?php for ($i = max(1, $page - 4); $i <= min($pages, $page + 4); $i++): ?><li class="page-item <?= $i === $page ? 'active' : '' ?>"><a class="page-link" href="?tab=<?= $tab ?>&p=<?= $i ?>"><?= $i ?></a></li><?php endfor; ?></ul></nav>
<?php admin_foot(); ?>
