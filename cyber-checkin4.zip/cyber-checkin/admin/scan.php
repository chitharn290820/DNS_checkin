<?php
require __DIR__ . '/../config.php';
require __DIR__ . '/../includes/layout.php';
require_admin();
admin_head('สแกน QR', 'scan'); ?>
<div class="text-center mb-3"><h3 class="font-cyber"><i class="bi bi-qr-code-scan text-info"></i> SCAN STATION</h3>
  <div class="text-secondary small">ถอดรหัส QR ในเครื่องนี้ทั้งหมด (ไม่ใช้สคริปต์ภายนอก) · ต้องเปิดผ่าน http://localhost หรือ HTTPS เพื่อให้เบราว์เซอร์อนุญาตใช้กล้อง</div></div>
<div class="scan-wrap">
  <div class="btn-group w-100 mb-3" role="group" id="modes">
    <input type="radio" class="btn-check" name="mode" id="m-auto" value="auto" checked><label class="btn btn-outline-cyan" for="m-auto">อัตโนมัติ (เข้า/ออก)</label>
    <input type="radio" class="btn-check" name="mode" id="m-in" value="in"><label class="btn btn-outline-success" for="m-in">เข้างาน</label>
    <input type="radio" class="btn-check" name="mode" id="m-out" value="out"><label class="btn btn-outline-warning" for="m-out">ออกงาน</label>
  </div>
  <div id="stage" class="stage mb-2">
    <video id="video" playsinline muted autoplay></video><canvas id="ov" class="ov"></canvas><div id="hud" class="hud">กำลังเปิดกล้อง…</div>
  </div>
  <div id="camErr" class="alert alert-danger py-2 small" style="display:none"></div>
  <div class="d-flex gap-2 mb-2 justify-content-center">
    <button class="btn btn-outline-cyan btn-sm" id="btnToggle"><i class="bi bi-camera-video"></i> เปิด/ปิดกล้อง</button>
    <button class="btn btn-outline-cyan btn-sm" data-bs-toggle="collapse" data-bs-target="#camPanel"><i class="bi bi-gear"></i> ตั้งค่ากล้อง</button>
  </div>
  <div class="collapse mb-3" id="camPanel"><div class="glass p-3 small" id="camBody"></div></div>
  <form id="manual" class="input-group mb-3">
    <span class="input-group-text bg-transparent text-info border-secondary"><i class="bi bi-keyboard"></i></span>
    <input class="form-control font-cyber" id="code" maxlength="20" placeholder="พิมพ์/ยิงรหัสด้วยเครื่องสแกนที่นี่" autocomplete="off">
    <button class="btn btn-cyber">ตกลง</button>
  </form>
  <div id="result" class="scan-result text-center" style="display:none"></div>
  <div class="glass p-3 mt-3 small d-flex justify-content-around text-center">
    <div>สแกนในเครื่องนี้<div class="fs-4 font-cyber" id="cnt">0</div></div>
    <div>สำเร็จ<div class="fs-4 font-cyber text-success" id="cntOk">0</div></div>
    <div>ถูกปฏิเสธ<div class="fs-4 font-cyber text-danger" id="cntBad">0</div></div>
  </div>
</div>
<?php admin_foot('<script src="../assets/vendor/jsqr/jsQR.js"></script>
<script src="../assets/js/scanner.js"></script>
<script>
const CSRF=' . json_encode(csrf_token()) . ';
const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"\']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","\'":"&#39;"}[c]));
let busy=false,cnt=0,ok=0,bad=0;
function beep(good){try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.connect(g);g.connect(c.destination);o.frequency.value=good?880:220;g.gain.value=.15;o.start();o.stop(c.currentTime+(good?.15:.4));}catch(e){}}
async function send(token,method){
  if(busy)return;busy=true;
  const mode=document.querySelector("input[name=mode]:checked").value;
  const fd=new FormData();fd.append("token",token);fd.append("mode",mode);fd.append("method",method);
  let d;
  try{const r=await fetch("api_checkin.php",{method:"POST",headers:{"X-CSRF-Token":CSRF},body:fd});d=await r.json();}
  catch(e){d={ok:false,level:"bad",msg:"เชื่อมต่อเซิร์ฟเวอร์ไม่ได้"};}
  cnt++;d.ok?ok++:bad++;$("cnt").textContent=cnt;$("cntOk").textContent=ok;$("cntBad").textContent=bad;
  const box=$("result");box.style.display="block";box.className="scan-result text-center "+(d.level||"bad");
  const icon=d.level==="ok"?"bi-check-circle-fill text-success":d.level==="warn"?"bi-exclamation-triangle-fill text-warning":"bi-x-octagon-fill text-danger";
  let h=`<i class="bi ${icon}" style="font-size:3rem"></i><div class="fs-5 fw-bold mt-1">${esc(d.msg)}</div>`;
  if(d.name)h+=`<div class="fs-4 mt-2">${esc(d.name)}</div><div class="text-secondary">${esc(d.org)} · ${esc(d.type)}</div>`;
  if(d.in)h+=`<div class="mt-2"><i class="bi bi-box-arrow-in-right text-success"></i> เข้า: ${esc(d.in)}</div>`;
  if(d.out)h+=`<div><i class="bi bi-box-arrow-right text-warning"></i> ออก: ${esc(d.out)}</div>`;
  if(d.duration)h+=`<div class="font-cyber fs-5 text-info mt-1">อยู่ในงาน ${esc(d.duration)}</div>`;
  box.innerHTML=h;beep(d.ok);if(navigator.vibrate)navigator.vibrate(d.ok?60:[80,60,80]);
  setTimeout(()=>{busy=false;},1200);
}
let lastTok="",lastT=0;
function onScan(txt,method){txt=String(txt).trim();if(txt===lastTok&&Date.now()-lastT<8000)return;lastTok=txt;lastT=Date.now();send(txt,method||"scan");}
Scanner.init({
  videoEl:$("video"),overlayEl:$("ov"),stageEl:$("stage"),hudEl:$("hud"),panelEl:$("camBody"),
  onCode:onScan,
  onError:t=>{const e=$("camErr");e.textContent=t;e.style.display="block";$("hud").textContent="ไม่มีภาพจากกล้อง";}
}).then(okc=>{if(okc)$("camErr").style.display="none";});
$("btnToggle").onclick=async()=>{const on=await Scanner.toggle();if(on)$("camErr").style.display="none";else $("hud").textContent="ปิดกล้องอยู่";};
$("manual").onsubmit=ev=>{ev.preventDefault();const v=$("code").value.trim();if(v){send(v,"manual");$("code").value="";}$("code").focus();};
</script>'); ?>
