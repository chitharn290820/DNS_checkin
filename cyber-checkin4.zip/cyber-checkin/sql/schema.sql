-- ระบบเช็คอินงาน "สมรภูมิไซเบอร์ยุคปัญญาประดิษฐ์ (AI)"
-- นำเข้าด้วย: mysql -u root -p < sql/schema.sql
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS cyber_checkin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cyber_checkin;
SET time_zone = '+07:00';

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(120) NOT NULL,
  role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
  last_login DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS participants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_code CHAR(20) NOT NULL UNIQUE,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  organization VARCHAR(150) NOT NULL,
  p_type VARCHAR(30) NOT NULL DEFAULT 'นักศึกษา',
  status ENUM('registered','cancelled') NOT NULL DEFAULT 'registered',
  source ENUM('web','import','admin') NOT NULL DEFAULT 'web',
  checkin_at DATETIME NULL,
  checkout_at DATETIME NULL,
  duration_sec INT NULL,
  is_late TINYINT(1) NOT NULL DEFAULT 0,
  checkin_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_checkin (checkin_at),
  INDEX idx_org (organization)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS checkin_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  participant_id INT NOT NULL,
  action ENUM('in','out') NOT NULL,
  scanned_at DATETIME NOT NULL,
  admin_id INT NULL,
  method ENUM('scan','manual') NOT NULL DEFAULT 'scan',
  ip VARCHAR(45) NULL,
  INDEX idx_p (participant_id),
  INDEX idx_t (scanned_at),
  FOREIGN KEY (participant_id) REFERENCES participants(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS security_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  event_type VARCHAR(40) NOT NULL,
  detail VARCHAR(500) NULL,
  ip VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_c (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rate_limits (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45) NOT NULL,
  action VARCHAR(40) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_rl (ip, action, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  k VARCHAR(50) PRIMARY KEY,
  v VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO settings (k, v) VALUES
 ('event_name','สมรภูมิไซเบอร์ยุคปัญญาประดิษฐ์ (AI Cyber Battlefield)'),
 ('event_start','2026-11-15 08:30:00'),
 ('event_end','2026-11-15 16:30:00'),
 ('venue','คณะนวัตกรรมดิจิทัล มจพ. กรุงเทพมหานคร'),
 ('late_grace_min','30'),
 ('scan_cooldown_sec','10');

-- ผู้ดูแลเริ่มต้น  user: admin  /  password: Admin@2026   (** เปลี่ยนรหัสผ่านทันทีหลังติดตั้ง **)
INSERT IGNORE INTO admins (username, password_hash, full_name, role) VALUES
 ('admin','$2y$10$Mpz8aahAMTEw075op6NdeuLU8XPWdH4IUZD3oQUUslTc8FgmGPOuG','ผู้ดูแลระบบ','admin');
