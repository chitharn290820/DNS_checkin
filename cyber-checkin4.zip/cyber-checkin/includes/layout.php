<?php
function brandbar(string $base = ''): void { ?>
<header class="brandbar py-2 no-print">
  <div class="container-xl d-flex align-items-center gap-3">
    <div class="logo"><img src="<?= $base ?>assets/img/logo.png" alt="" onerror="this.remove();this.parentNode.innerHTML='<i class=&quot;bi bi-shield-lock-fill&quot;></i>'"></div>
    <div class="text-white lh-sm">
      <div class="fw-bold fs-5"><?= e(UNI_TH) ?></div>
      <small><?= e(FAC_TH) ?> · <?= e(DEPT_TH) ?></small>
    </div>
  </div>
</header>
<?php }

function html_head(string $title, string $base = ''): void { ?>
<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> | <?= e(setting('event_name', 'Cyber Battlefield')) ?></title>
<link href="<?= $base ?>assets/vendor/fonts.css" rel="stylesheet">
<link href="<?= $base ?>assets/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/vendor/icons/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= $base ?>assets/css/theme.css?v=2" rel="stylesheet">
</head>
<body>
<?php }

function html_foot(string $extra = '', string $base = ''): void { ?>
<script src="<?= $base ?>assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<?= $extra ?>
</body></html>
<?php }

function admin_head(string $title, string $active): void {
    html_head($title, '../');
    $u = $_SESSION['admin'];
    $menu = [
        'index' => ['bi-speedometer2', 'Dashboard', 'index.php'],
        'scan' => ['bi-qr-code-scan', 'สแกน QR เข้า-ออกงาน', 'scan.php'],
        'participants' => ['bi-people-fill', 'ผู้ลงทะเบียน', 'participants.php'],
        'import' => ['bi-cloud-upload', 'นำเข้าข้อมูล (CSV)', 'import.php'],
        'logs' => ['bi-journal-text', 'ประวัติ / ความปลอดภัย', 'logs.php'],
        'settings' => ['bi-gear-fill', 'ตั้งค่า / บัญชี', 'settings.php'],
    ];
    brandbar('../'); ?>
<div class="d-lg-flex">
  <nav class="sidebar py-3 no-print">
    <div class="px-3 pb-3 text-center">
      <div class="tag font-cyber">CONTROL ROOM</div>
      <div class="mt-2 small text-secondary"><i class="bi bi-person-circle"></i> <?= e($u['full_name']) ?> (<?= e($u['role']) ?>)</div>
    </div>
    <ul class="nav flex-column">
      <?php foreach ($menu as $k => [$ic, $lb, $href]): ?>
        <li><a class="nav-link <?= $k === $active ? 'active' : '' ?>" href="<?= $href ?>"><i class="bi <?= $ic ?> me-2"></i><?= $lb ?></a></li>
      <?php endforeach; ?>
      <li><a class="nav-link" href="../index.php" target="_blank"><i class="bi bi-box-arrow-up-right me-2"></i>หน้าบ้าน</a></li>
      <li><a class="nav-link text-danger" href="logout.php"><i class="bi bi-power me-2"></i>ออกจากระบบ</a></li>
    </ul>
  </nav>
  <main class="flex-grow-1 p-3 p-lg-4" style="min-width:0">
<?php }

function admin_foot(string $extra = ''): void { ?>
  </main>
</div>
<?php html_foot($extra, '../'); }
