/*
 * QRTicket — สร้าง QR บัตรเข้างานแบบ "กำหนดค่าตายตัว" ให้อ่านง่ายที่สุด
 *  - Error Correction = H (ซ่อมได้ ~30%)
 *  - โหมด Alphanumeric (รหัส 20 ตัว A-F/0-9 พอดี Version 2 = 25x25 โมดูล ต่ำสุดที่ ECC-H รองรับ)
 *    → โมดูลใหญ่ที่สุดเท่าที่เป็นไปได้ เมื่อแสดงในพื้นที่เท่ากัน
 *  - ดำล้วน #000 บนขาวล้วน #FFF, ไม่มีโลโก้/ไล่สี/มุมมน, Quiet zone = 4 โมดูล (ตามมาตรฐาน ISO 18004)
 *  - ภาพ PNG ใช้ขนาดโมดูลเป็นจำนวนเต็มพิกเซล ไม่มี anti-alias
 *  - ใช้ไลบรารีในเครื่อง (assets/vendor/qrgen) ไม่เรียกจากอินเทอร์เน็ต
 */
(function (w) {
  'use strict';
  var QUIET = 4;
  var ALNUM = /^[0-9A-Z $%*+\-.\/:]+$/;

  function build(text) {
    text = String(text);
    var qr = qrcode(0, 'H');                                // 0 = เลือก version ต่ำสุดที่พอดีข้อมูล
    qr.addData(text, ALNUM.test(text) ? 'Alphanumeric' : 'Byte');
    qr.make();
    return qr;
  }

  function svg(qr, px) {
    px = px || 9;
    var n = qr.getModuleCount(), size = n + QUIET * 2, d = '';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++)
      if (qr.isDark(r, c)) d += 'M' + (c + QUIET) + ' ' + (r + QUIET) + 'h1v1h-1z';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + ' ' + size + '" ' +
      'width="' + (size * px) + '" height="' + (size * px) + '" shape-rendering="crispEdges" ' +
      'style="display:block;max-width:100%;height:auto;background:#fff">' +
      '<rect width="' + size + '" height="' + size + '" fill="#fff"/><path d="' + d + '" fill="#000"/></svg>';
  }

  function canvas(qr, ppm) {
    ppm = ppm || 16;                                        // พิกเซลต่อโมดูล (จำนวนเต็มเสมอ)
    var n = qr.getModuleCount(), size = (n + QUIET * 2) * ppm;
    var cv = document.createElement('canvas'); cv.width = cv.height = size;
    var x = cv.getContext('2d'); x.imageSmoothingEnabled = false;
    x.fillStyle = '#fff'; x.fillRect(0, 0, size, size); x.fillStyle = '#000';
    for (var r = 0; r < n; r++) for (var c = 0; c < n; c++)
      if (qr.isDark(r, c)) x.fillRect((c + QUIET) * ppm, (r + QUIET) * ppm, ppm, ppm);
    return cv;
  }

  /** ถอดรหัสภาพที่สร้างเองกลับมา เพื่อยืนยันว่าอ่านได้จริง (self-test) */
  function verify(cv) {
    if (typeof jsQR !== 'function') return null;
    var s = 400, t = document.createElement('canvas'); t.width = t.height = s;
    var x = t.getContext('2d'); x.imageSmoothingEnabled = true; x.drawImage(cv, 0, 0, s, s);
    var im = x.getImageData(0, 0, s, s), r = jsQR(im.data, s, s);
    return r ? r.data : '';
  }

  w.QRTicket = { build: build, svg: svg, canvas: canvas, verify: verify };
})(window);
