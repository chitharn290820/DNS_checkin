/*
 * Scanner — ตัวอ่าน QR ที่รันในเบราว์เซอร์ของเครื่อง host ทั้งหมด (ไม่โหลดสคริปต์จากภายนอก)
 *  - ถอดรหัสด้วย jsQR (assets/vendor/jsqr) + BarcodeDetector ของระบบ (ถ้ามี)
 *  - หลายรอบการประมวลผลต่อเฟรม: ภาพดิบ → ปรับระดับแสงอัตโนมัติ → ปรับคมชัด → เต็มเฟรม
 *  - ตั้งค่ากล้องได้: เลือกกล้อง/ความละเอียด/ซูม/โฟกัส/ไฟฉาย/exposure (ถ้ากล้องรองรับ)
 *    และปรับซอฟต์แวร์: สว่าง/คอนทราสต์/คมชัด/พื้นที่สแกน/ความเร็ว ใช้ได้กับทุกกล้อง
 *  ใช้งาน: Scanner.init({ onCode(text,method), videoEl, overlayEl, stageEl, panelEl, hudEl, fileEl })
 */
(function (w) {
  'use strict';
  const LS = 'cc_scan_cfg_v1';
  const DEF = { deviceId: '', res: '1280', roi: 80, rate: 15, bright: 0, contrast: 100,
                levels: true, sharpen: false, mirror: false, engine: 'auto', hw: {} };
  const RES = { '640': [640, 480], '1280': [1280, 720], '1920': [1920, 1080] };
  let cfg = Object.assign({}, DEF);
  try { Object.assign(cfg, JSON.parse(localStorage.getItem(LS) || '{}')); } catch (e) {}
  const save = () => { try { localStorage.setItem(LS, JSON.stringify(cfg)); } catch (e) {} };

  let o = {}, video, ov, stage, hud, stream = null, track = null, caps = {}, running = false;
  let detector = null, timer = null, frameNo = 0, decodes = 0, lastRate = 0, lastQrPx = 0, lastHit = 0, startedAt = 0;
  const wc = document.createElement('canvas'), wx = wc.getContext('2d', { willReadFrequently: true });

  /* ---------- ประมวลผลภาพ ---------- */
  function gray(d, n) { const g = new Uint8ClampedArray(n); for (let i = 0, j = 0; i < n; i++, j += 4) g[i] = (d[j] * 77 + d[j + 1] * 150 + d[j + 2] * 29) >> 8; return g; }
  function lut(g, f) { const t = new Uint8ClampedArray(256); for (let i = 0; i < 256; i++) t[i] = f(i); for (let i = 0; i < g.length; i++) g[i] = t[g[i]]; }
  function autoLevels(g) {
    const h = new Uint32Array(256); for (let i = 0; i < g.length; i++) h[g[i]]++;
    const lo = pct(h, g.length * 0.01), hi = pct(h, g.length * 0.99);
    if (hi - lo < 24) return;                                   // ภาพแบนมาก ไม่ควรขยายจนเป็นสัญญาณรบกวน
    const k = 255 / (hi - lo); lut(g, v => (v - lo) * k);
  }
  function pct(h, target) { let s = 0; for (let i = 0; i < 256; i++) { s += h[i]; if (s >= target) return i; } return 255; }
  function sharpen(g, W, H) {
    const src = g.slice();
    for (let y = 1; y < H - 1; y++) for (let x = 1; x < W - 1; x++) {
      const i = y * W + x; g[i] = 5 * src[i] - src[i - 1] - src[i + 1] - src[i - W] - src[i + W];
    }
  }
  function put(g, d) { for (let i = 0, j = 0; i < g.length; i++, j += 4) { d[j] = d[j + 1] = d[j + 2] = g[i]; d[j + 3] = 255; } }

  // รอบการอ่านที่หมุนเวียนต่อเฟรม (กันกินซีพียูเกินไป แต่ครอบคลุมสภาพภาพหลายแบบ)
  const PASSES = [
    { roi: true,  lv: false, sh: false },
    { roi: true,  lv: true,  sh: false },
    { roi: true,  lv: true,  sh: true  },
    { roi: false, lv: true,  sh: false },
  ];

  function grab(src, sw0, sh0, useRoi) {
    let sx = 0, sy = 0, sw = sw0, sh = sh0;
    if (useRoi) { const s = Math.floor(Math.min(sw0, sh0) * cfg.roi / 100); sw = sh = s; sx = (sw0 - s) >> 1; sy = (sh0 - s) >> 1; }
    const big = Math.max(sw, sh); let sc = 1;
    if (big > 960) sc = 960 / big; else if (big < 480) sc = 480 / big;     // ย่อภาพใหญ่ / ขยายภาพเล็ก ให้อยู่ช่วงที่ถอดรหัสได้ดี
    const W = Math.round(sw * sc), H = Math.round(sh * sc);
    if (wc.width !== W || wc.height !== H) { wc.width = W; wc.height = H; }
    wx.imageSmoothingEnabled = true; wx.imageSmoothingQuality = 'high';
    wx.drawImage(src, sx, sy, sw, sh, 0, 0, W, H);
    return { im: wx.getImageData(0, 0, W, H), W, H, sx, sy, sc };
  }

  function runPass(p, src, sw, sh) {
    const f = grab(src, sw, sh, p.roi), d = f.im.data, n = f.W * f.H, g = gray(d, n);
    if (p.lv && cfg.levels) autoLevels(g);
    if (cfg.bright !== 0 || cfg.contrast !== 100) { const c = cfg.contrast / 100, b = cfg.bright * 1.28; lut(g, v => (v - 128) * c + 128 + b); }
    if (p.sh || cfg.sharpen) sharpen(g, f.W, f.H);
    put(g, d);
    const r = jsQR(d, f.W, f.H, { inversionAttempts: 'attemptBoth' });
    if (!r) return null;
    const L = r.location, map = q => ({ x: q.x / f.sc + f.sx, y: q.y / f.sc + f.sy });
    return { text: r.data, pts: [L.topLeftCorner, L.topRightCorner, L.bottomRightCorner, L.bottomLeftCorner].map(map) };
  }

  async function decodeFrame(src, sw, sh, passIdx) {
    if (detector) {
      try {
        const a = await detector.detect(src);
        if (a.length && a[0].rawValue) return { text: a[0].rawValue, pts: (a[0].cornerPoints || []).map(p => ({ x: p.x, y: p.y })), via: 'native' };
      } catch (e) {}
    }
    if (typeof jsQR !== 'function' || (cfg.engine === 'native' && detector)) return null;
    const r = runPass(PASSES[passIdx % PASSES.length], src, sw, sh);
    return r ? Object.assign(r, { via: 'jsQR' }) : null;
  }

  /* ---------- วงจรสแกน ---------- */
  async function loop() {
    if (!running) return;
    const t0 = performance.now();
    if (video.readyState >= 2 && video.videoWidth && !document.hidden) {
      const r = await decodeFrame(video, video.videoWidth, video.videoHeight, frameNo++);
      decodes++;
      drawOverlay(r);
      if (r && r.text) {
        lastHit = Date.now();
        const p = r.pts; if (p.length >= 2) lastQrPx = Math.round(Math.hypot(p[1].x - p[0].x, p[1].y - p[0].y));
        o.onCode(String(r.text).trim(), 'scan');
      }
    }
    const wait = Math.max(5, 1000 / cfg.rate - (performance.now() - t0));
    timer = setTimeout(loop, wait);
  }

  function drawOverlay(r) {
    const vw = video.videoWidth, vh = video.videoHeight; if (!vw) return;
    if (ov.width !== vw || ov.height !== vh) { ov.width = vw; ov.height = vh; }
    const x = ov.getContext('2d'); x.clearRect(0, 0, vw, vh);
    const s = Math.floor(Math.min(vw, vh) * cfg.roi / 100), sx = (vw - s) >> 1, sy = (vh - s) >> 1, lw = Math.max(2, vw / 320);
    x.fillStyle = 'rgba(0,0,0,.35)'; x.beginPath(); x.rect(0, 0, vw, vh); x.rect(sx, sy, s, s); x.fill('evenodd');
    x.strokeStyle = '#00e5ff'; x.lineWidth = lw; x.strokeRect(sx, sy, s, s);
    if (r && r.pts && r.pts.length === 4) {
      x.strokeStyle = '#25e08a'; x.lineWidth = lw * 2; x.beginPath();
      r.pts.forEach((p, i) => i ? x.lineTo(p.x, p.y) : x.moveTo(p.x, p.y)); x.closePath(); x.stroke();
    }
  }

  function updateHud() {
    if (!hud) return;
    const st = track ? track.getSettings() : {}, now = Date.now();
    const rate = decodes; decodes = 0;
    let hint = '';
    if (running && now - Math.max(lastHit, startedAt) > 8000) hint = ' · ไม่พบ QR: ขยับให้อยู่ในกรอบ/เพิ่มแสง/ลองค่าแนะนำ "กล้องแย่"';
    else if (lastQrPx && now - lastHit < 3000 && lastQrPx < 90) hint = ' · QR เล็ก (' + lastQrPx + 'px) เข้าใกล้ขึ้นหรือเพิ่มซูม';
    hud.textContent = (st.width ? st.width + '×' + st.height : '-') + ' · ' + (detector ? 'native+jsQR' : 'jsQR') + ' · ' + rate * 2 + ' เฟรม/วินาที' + hint;
  }

  /* ---------- กล้อง ---------- */
  async function start() {
    stop();
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      msg('เบราว์เซอร์ไม่อนุญาตใช้กล้อง: ต้องเปิดผ่าน http://localhost หรือ https:// เท่านั้น (ตอนนี้เป็น ' + location.origin + ')'); return false;
    }
    const [W, H] = RES[cfg.res] || RES['1280'];
    const v = { width: { ideal: W }, height: { ideal: H }, frameRate: { ideal: 30 } };
    if (cfg.deviceId) v.deviceId = { exact: cfg.deviceId }; else v.facingMode = { ideal: 'environment' };
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: false, video: v }); }
    catch (e) {
      if (cfg.deviceId && (e.name === 'OverconstrainedError' || e.name === 'NotFoundError')) { cfg.deviceId = ''; save(); return start(); }
      const m = { NotAllowedError: 'ถูกปฏิเสธสิทธิ์กล้อง — กดไอคอนกุญแจ/กล้องที่แถบที่อยู่แล้วอนุญาต', NotFoundError: 'ไม่พบกล้องในเครื่องนี้',
                  NotReadableError: 'กล้องถูกโปรแกรมอื่นใช้อยู่ (ปิดแอปอื่น/แท็บอื่นที่เปิดกล้อง) หรือไดรเวอร์มีปัญหา' };
      msg((m[e.name] || 'เปิดกล้องไม่ได้: ' + e.name) + ' — ใช้ช่องกรอกรหัส/เครื่องยิงบาร์โค้ดแทนได้'); return false;
    }
    video.srcObject = stream; video.setAttribute('playsinline', ''); await video.play().catch(() => {});
    track = stream.getVideoTracks()[0]; caps = track.getCapabilities ? track.getCapabilities() : {};
    await applyHw(cfg.hw, true);
    await initDetector();
    running = true; startedAt = Date.now(); frameNo = 0; clearTimeout(timer); loop();
    buildPanel(); return true;
  }
  function stop() {
    running = false; clearTimeout(timer);
    if (stream) stream.getTracks().forEach(t => t.stop());
    stream = track = null; if (video) video.srcObject = null;
  }
  async function applyHw(obj, quiet) {
    if (!track || !obj) return;
    const adv = {}; for (const k in obj) if (caps[k] !== undefined && obj[k] !== null && obj[k] !== '') adv[k] = obj[k];
    if (!Object.keys(adv).length) return;
    try { await track.applyConstraints({ advanced: [adv] }); } catch (e) { if (!quiet) console.warn('applyConstraints', e); }
  }
  async function initDetector() {
    detector = null;
    if (cfg.engine === 'jsqr' || !('BarcodeDetector' in w)) return;
    try { if ((await BarcodeDetector.getSupportedFormats()).includes('qr_code')) detector = new BarcodeDetector({ formats: ['qr_code'] }); } catch (e) {}
  }
  function msg(t) { if (o.onError) o.onError(t); }

  /* ---------- แผงตั้งค่า ---------- */
  const E = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function range(id, label, min, max, step, val, unit) {
    return '<div class="mb-2"><div class="d-flex justify-content-between"><label for="' + id + '">' + label + '</label><span class="text-info" id="' + id + 'V">' + val + (unit || '') + '</span></div>' +
      '<input type="range" class="form-range" id="' + id + '" min="' + min + '" max="' + max + '" step="' + step + '" value="' + val + '"></div>';
  }
  function sw(id, label, on) { return '<div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="' + id + '"' + (on ? ' checked' : '') + '><label class="form-check-label" for="' + id + '">' + label + '</label></div>'; }

  async function buildPanel() {
    const P = o.panelEl; if (!P) return;
    let devs = []; try { devs = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput'); } catch (e) {}
    const cur = track ? track.getSettings().deviceId : '';
    let h = '<div class="fw-semibold mb-2"><i class="bi bi-camera-video"></i> กล้อง</div>' +
      '<select id="cfgDev" class="form-select form-select-sm mb-2">' + devs.map((d, i) => '<option value="' + E(d.deviceId) + '"' + (d.deviceId === cur ? ' selected' : '') + '>' + E(d.label || 'กล้อง ' + (i + 1)) + '</option>').join('') + '</select>' +
      '<select id="cfgRes" class="form-select form-select-sm mb-2">' + [['640', '640×480 (เร็ว/เบา)'], ['1280', '1280×720 (แนะนำ)'], ['1920', '1920×1080 (ละเอียดสุด)']].map(r => '<option value="' + r[0] + '"' + (cfg.res === r[0] ? ' selected' : '') + '>' + r[1] + '</option>').join('') + '</select>';
    const hw = [];
    if (caps.zoom) hw.push(range('hwZoom', 'ซูม', caps.zoom.min, caps.zoom.max, caps.zoom.step || 0.1, cfg.hw.zoom ?? caps.zoom.min, '×'));
    if (caps.focusMode && caps.focusMode.length) hw.push('<div class="mb-2"><label>โฟกัส</label><select id="hwFocus" class="form-select form-select-sm">' + caps.focusMode.map(m => '<option' + ((cfg.hw.focusMode || 'continuous') === m ? ' selected' : '') + '>' + E(m) + '</option>').join('') + '</select></div>');
    if (caps.focusDistance) hw.push(range('hwFd', 'ระยะโฟกัส (เมื่อเลือก manual)', caps.focusDistance.min, caps.focusDistance.max, caps.focusDistance.step || 0.01, cfg.hw.focusDistance ?? caps.focusDistance.min, ''));
    if (caps.exposureCompensation) hw.push(range('hwEv', 'Exposure', caps.exposureCompensation.min, caps.exposureCompensation.max, caps.exposureCompensation.step || 0.1, cfg.hw.exposureCompensation ?? 0, ''));
    if (caps.brightness) hw.push(range('hwBr', 'Brightness (กล้อง)', caps.brightness.min, caps.brightness.max, caps.brightness.step || 1, cfg.hw.brightness ?? ((caps.brightness.min + caps.brightness.max) / 2), ''));
    if (caps.contrast) hw.push(range('hwCt', 'Contrast (กล้อง)', caps.contrast.min, caps.contrast.max, caps.contrast.step || 1, cfg.hw.contrast ?? ((caps.contrast.min + caps.contrast.max) / 2), ''));
    if (caps.sharpness) hw.push(range('hwSh', 'Sharpness (กล้อง)', caps.sharpness.min, caps.sharpness.max, caps.sharpness.step || 1, cfg.hw.sharpness ?? caps.sharpness.min, ''));
    if (caps.torch) hw.push(sw('hwTorch', 'ไฟฉาย', !!cfg.hw.torch));
    h += hw.length ? hw.join('') : '<div class="text-secondary mb-2">กล้อง/เบราว์เซอร์นี้ไม่เปิดให้ปรับฮาร์ดแวร์ (เช่น Firefox, เว็บแคมบางรุ่น) — ใช้การปรับซอฟต์แวร์ด้านล่างแทนได้ทุกกรณี</div>';
    h += '<hr class="my-2"><div class="fw-semibold mb-2"><i class="bi bi-sliders"></i> ปรับภาพก่อนถอดรหัส (ซอฟต์แวร์)</div>' +
      range('swBr', 'ความสว่าง', -100, 100, 5, cfg.bright, '') + range('swCt', 'คอนทราสต์', 50, 300, 10, cfg.contrast, '%') +
      range('swRoi', 'ขนาดพื้นที่สแกน (กรอบกลางภาพ)', 40, 100, 5, cfg.roi, '%') + range('swRate', 'ความถี่ถอดรหัส (ครั้ง/วินาที)', 3, 30, 1, cfg.rate, '') +
      sw('swLv', 'ปรับระดับแสงอัตโนมัติ (Auto-levels)', cfg.levels) + sw('swSh', 'เพิ่มความคมชัดทุกเฟรม', cfg.sharpen) + sw('swMir', 'กลับด้านภาพที่แสดง (ไม่กระทบการอ่าน)', cfg.mirror) +
      '<div class="mt-2"><label>เอ็นจินอ่าน</label><select id="swEng" class="form-select form-select-sm">' + [['auto', 'อัตโนมัติ (native ถ้ามี + jsQR)'], ['jsqr', 'jsQR อย่างเดียว'], ['native', 'native อย่างเดียว']].map(r => '<option value="' + r[0] + '"' + (cfg.engine === r[0] ? ' selected' : '') + '>' + r[1] + '</option>').join('') + '</select></div>' +
      '<div class="d-flex flex-wrap gap-2 mt-3"><button class="btn btn-sm btn-outline-cyan" id="pLow">ค่าแนะนำ "กล้องแย่/แสงน้อย"</button><button class="btn btn-sm btn-outline-secondary" id="pDef">คืนค่าเริ่มต้น</button>' +
      '<label class="btn btn-sm btn-outline-cyan mb-0"><i class="bi bi-image"></i> ทดสอบอ่านจากไฟล์ภาพ<input type="file" accept="image/*" id="swFile" hidden></label></div><div id="swFileOut" class="mt-2 font-cyber"></div>';
    P.innerHTML = h; bind();
  }

  function bind() {
    const $ = id => document.getElementById(id);
    const rg = (id, fn, unit) => { const el = $(id); if (!el) return; el.oninput = () => { $(id + 'V').textContent = el.value + (unit || ''); fn(+el.value); save(); }; };
    const hwSet = (k, v) => { cfg.hw[k] = v; applyHw({ [k]: v }); };
    $('cfgDev').onchange = e => { cfg.deviceId = e.target.value; save(); start(); };
    $('cfgRes').onchange = e => { cfg.res = e.target.value; save(); start(); };
    rg('hwZoom', v => hwSet('zoom', v), '×'); rg('hwFd', v => hwSet('focusDistance', v)); rg('hwEv', v => hwSet('exposureCompensation', v));
    rg('hwBr', v => hwSet('brightness', v)); rg('hwCt', v => hwSet('contrast', v)); rg('hwSh', v => hwSet('sharpness', v));
    if ($('hwFocus')) $('hwFocus').onchange = e => { hwSet('focusMode', e.target.value); save(); };
    if ($('hwTorch')) $('hwTorch').onchange = e => { cfg.hw.torch = e.target.checked; applyHw({ torch: e.target.checked }); save(); };
    rg('swBr', v => cfg.bright = v); rg('swCt', v => cfg.contrast = v, '%'); rg('swRoi', v => cfg.roi = v, '%'); rg('swRate', v => cfg.rate = v);
    $('swLv').onchange = e => { cfg.levels = e.target.checked; save(); };
    $('swSh').onchange = e => { cfg.sharpen = e.target.checked; save(); };
    $('swMir').onchange = e => { cfg.mirror = e.target.checked; o.stageEl.classList.toggle('mirror', cfg.mirror); save(); };
    $('swEng').onchange = async e => { cfg.engine = e.target.value; save(); await initDetector(); };
    $('pLow').onclick = () => { Object.assign(cfg, { res: '1280', roi: 90, rate: 12, bright: 15, contrast: 150, levels: true, sharpen: true }); save(); start(); };
    $('pDef').onclick = () => { cfg = JSON.parse(JSON.stringify(DEF)); save(); o.stageEl.classList.remove('mirror'); start(); };
    $('swFile').onchange = async e => {
      const f = e.target.files[0], out = $('swFileOut'); if (!f) return;
      try {
        const bmp = await createImageBitmap(f); let found = null;
        for (let i = 0; i < PASSES.length * 2 && !found; i++) { const p = Object.assign({}, PASSES[i % 4], { roi: false }); found = runPass(p, bmp, bmp.width, bmp.height); }
        out.innerHTML = found ? (/^[A-F0-9]{20}$/.test(found.text.trim().toUpperCase()) ? '<span class="text-success">อ่านได้: ' : '<span class="text-warning">อ่านได้แต่รูปแบบไม่ใช่บัตรงาน: ') + E(found.text) + '</span>' : '<span class="text-danger">อ่านไม่ได้</span>';
      } catch (err) { out.textContent = 'เปิดไฟล์ภาพไม่ได้'; }
      e.target.value = '';
    };
  }

  /* ---------- สาธารณะ ---------- */
  w.Scanner = {
    init(opt) {
      o = opt; video = o.videoEl; ov = o.overlayEl; stage = o.stageEl; hud = o.hudEl;
      stage.classList.toggle('mirror', !!cfg.mirror);
      setInterval(updateHud, 500);
      document.addEventListener('visibilitychange', () => { if (document.hidden) return; if (running && stream && track && track.readyState === 'ended') start(); });
      w.addEventListener('pagehide', stop);
      return start();
    },
    start, stop, isRunning: () => running,
    toggle() { return running ? (stop(), false) : start(); },
  };
})(window);
