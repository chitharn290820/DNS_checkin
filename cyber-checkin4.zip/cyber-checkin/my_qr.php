<?php
require __DIR__ . '/config.php';
require __DIR__ . '/includes/layout.php';
$t = strtoupper((string)($_GET['t'] ?? ''));
$p = null;
if (preg_match('/^[A-F0-9]{20}$/', $t)) {
    $st = db()->prepare('SELECT * FROM participants WHERE ticket_code=?'); $st->execute([$t]); $p = $st->fetch();
}
html_head('QR Code ของฉัน'); brandbar(); ?>
<div class="container py-4">
<?php if (!$p): ?>
  <div class="alert alert-danger text-center">ไม่พบข้อมูลบัตรเข้างาน <a href="index.php" class="alert-link">กลับหน้าแรก</a></div>
<?php else: ?>
  <?php if (!empty($_GET['new'])): ?><div class="alert alert-success text-center"><i class="bi bi-check-circle-fill"></i> ลงทะเบียนสำเร็จ! กรุณาบันทึกภาพ QR Code นี้ไว้แสดงในวันงาน</div><?php endif; ?>
  <div class="ticket glass" id="ticket">
    <div class="top text-white">
      <div class="small"><?= e(UNI_TH) ?></div>
      <div class="fw-bold font-cyber"><?= e(setting('event_name')) ?></div>
    </div>
    <div class="p-4 text-center">
      <div class="qrbox mb-2"><div id="qr" role="img" aria-label="QR Code บัตรเข้างาน"></div></div>
      <div id="qrstat" class="small mb-2 no-print"></div>
      <h4 class="mb-0"><?= e($p['full_name']) ?></h4>
      <div class="text-secondary"><?= e($p['organization']) ?> · <?= e($p['p_type']) ?></div>
      <div class="font-cyber text-info mt-2" style="letter-spacing:.15em"><?= e($p['ticket_code']) ?></div>
      <hr style="border-color:var(--line)">
      <div class="small text-secondary"><i class="bi bi-calendar-event"></i> <?= e(fmt_dt(setting('event_start'))) ?><br><i class="bi bi-geo-alt"></i> <?= e(setting('venue')) ?></div>
      <?php if ($p['status'] === 'cancelled'): ?><div class="alert alert-danger mt-3 py-1 mb-0">บัตรนี้ถูกยกเลิก</div><?php endif; ?>
      <?php if ($p['checkin_at']): ?><div class="alert alert-success mt-3 py-1 mb-0">เช็คอินแล้ว <?= e(fmt_dt($p['checkin_at'])) ?></div><?php endif; ?>
    </div>
  </div>
  <div class="text-center mt-3 no-print">
    <button class="btn btn-cyber" id="dl"><i class="bi bi-download"></i> บันทึกเป็นภาพ</button>
    <button class="btn btn-outline-cyan" id="big"><i class="bi bi-arrows-fullscreen"></i> แสดงเต็มจอ</button>
    <button class="btn btn-outline-cyan" onclick="print()"><i class="bi bi-printer"></i> พิมพ์</button>
    <a href="index.php" class="btn btn-outline-secondary">หน้าแรก</a>
  </div>
<?php endif; ?>
</div>
<?php if ($p): ?>
<script src="assets/vendor/qrgen/qrcode.js"></script>
<script src="assets/vendor/jsqr/jsQR.js"></script>
<script src="assets/js/qr-ticket.js"></script>
<script>
(function(){
  const code = <?= json_encode($p['ticket_code']) ?>;
  const qr = QRTicket.build(code);
  document.getElementById('qr').innerHTML = QRTicket.svg(qr, 9);
  // ทดสอบถอดรหัสภาพที่เพิ่งสร้าง — ต้องได้ค่าเดิมเป๊ะ
  const back = QRTicket.verify(QRTicket.canvas(qr, 16)), st = document.getElementById('qrstat');
  st.innerHTML = back === code
    ? '<span class="text-success"><i class="bi bi-patch-check-fill"></i> ตรวจสอบแล้ว: QR นี้อ่านค่าได้ถูกต้อง</span>'
    : '<span class="text-danger"><i class="bi bi-exclamation-triangle-fill"></i> สร้าง QR ไม่สมบูรณ์ กรุณารีเฟรชหน้า หรือแจ้งเจ้าหน้าที่ (ใช้รหัสด้านล่างแทนได้)</span>';
  document.getElementById('dl').onclick = function(){
    const a = document.createElement('a');
    a.href = QRTicket.canvas(qr, 20).toDataURL('image/png');          // 20 px/โมดูล ≈ 660x660 px
    a.download = 'QR-' + code + '.png'; a.click();
  };
  document.getElementById('big').onclick = function(){
    const o = document.createElement('div');
    o.style.cssText = 'position:fixed;inset:0;z-index:3000;background:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;color-scheme:light;forced-color-adjust:none;cursor:pointer';
    const s = Math.floor(Math.min(innerWidth, innerHeight) * 0.92);
    o.innerHTML = QRTicket.svg(qr, 1).replace(/width="\d+" height="\d+"/, 'width="' + s + '" height="' + s + '"') +
      '<div style="color:#000;font:600 16px sans-serif;margin-top:6px">' + code + ' — แตะเพื่อปิด</div>';
    o.onclick = () => o.remove(); document.body.appendChild(o);
  };
})();
</script>
<?php endif; html_foot();
