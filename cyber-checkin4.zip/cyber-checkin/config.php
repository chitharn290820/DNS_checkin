<?php
declare(strict_types=1);
/* ====== ตั้งค่าฐานข้อมูล ====== */
const DB_HOST = 'localhost';
const DB_NAME = 'cyber_checkin';
const DB_USER = 'root';
const DB_PASS = '';

const UNI_TH  = 'มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าพระนครเหนือ';
const FAC_TH  = 'คณะนวัตกรรมดิจิทัล';
const DEPT_TH = 'ภาควิชาบริหารเครือข่ายดิจิทัลและรักษาความปลอดภัยเทคโนโลยีสารสนเทศ';
const P_TYPES = ['นักศึกษา','บุคลากร','บุคคลทั่วไป','วิทยากร','ผู้บริหาร'];

ini_set('display_errors', '0');
date_default_timezone_set('Asia/Bangkok');
mb_internal_encoding('UTF-8');
ini_set('default_charset', 'UTF-8');
if (!headers_sent()) header('Content-Type: text/html; charset=UTF-8');

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Permissions-Policy: camera=(self)');
// บังคับให้โหลดสคริปต์/ฟอนต์/รูป/การเชื่อมต่อจากเซิร์ฟเวอร์ตัวเองเท่านั้น (ไม่พึ่ง CDN ภายนอก)
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; media-src 'self' blob:; connect-src 'self'; worker-src 'self' blob:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");

session_name('CYBERSESS');
session_set_cookie_params([
    'lifetime' => 0, 'path' => '/', 'httponly' => true,
    'samesite' => 'Strict', 'secure' => !empty($_SERVER['HTTPS']),
]);
session_start();

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec("SET time_zone = '+07:00'");
    }
    return $pdo;
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function client_ip(): string { return substr($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0', 0, 45); }
function now(): string { return date('Y-m-d H:i:s'); }

function setting(string $k, string $default = ''): string {
    static $all = null;
    if ($all === null) {
        $all = [];
        foreach (db()->query('SELECT k, v FROM settings') as $r) { $all[$r['k']] = $r['v']; }
    }
    return $all[$k] ?? $default;
}

/* ====== ระบบกรองภัยคุกคาม ====== */
function detect_threat(string $s): ?string {
    if ($s === '') return null;
    $v = urldecode($s);
    $rules = [
        'XSS'            => '/<\s*(script|iframe|object|embed|svg|img|link|meta|style|body)|javascript\s*:|vbscript\s*:|\bon\w+\s*=|data\s*:\s*text\/html/i',
        'SQL Injection'  => '/(\bunion\b.{0,30}\bselect\b|\bselect\b.{0,60}\bfrom\b|\binsert\s+into\b|\bdrop\s+(table|database)\b|\bdelete\s+from\b|\bupdate\b.{0,40}\bset\b|\b(or|and)\b\s+[\'"]?\d+[\'"]?\s*=\s*[\'"]?\d+|;\s*--|\/\*|\*\/|\bsleep\s*\(|\bbenchmark\s*\(|\bload_file\s*\(|\binto\s+(out|dump)file\b|\bxp_cmdshell\b|\binformation_schema\b)/i',
        'Code Injection' => '/(<\?php|<\?=|\bbase64_decode\s*\(|\beval\s*\(|\bsystem\s*\(|\bexec\s*\(|\bpassthru\s*\(|\bshell_exec\s*\(|`|\$\(|\$\{)/i',
        'Path Traversal' => '/(\.\.\/|\.\.\\\\|%2e%2e|\/etc\/passwd|c:\\\\windows)/i',
        'Null Byte'      => '/\x00|%00/',
    ];
    foreach ($rules as $name => $re) {
        if (preg_match($re, $s) || preg_match($re, $v)) return $name;
    }
    return null;
}

/** ทำความสะอาดข้อความ (ตัด tag, control char, ตัวนำสูตร Excel) */
function clean_text($s, int $max = 150): string {
    $s = (string)$s;
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s) ?? '';
    $s = strip_tags($s);
    $s = preg_replace('/\s+/u', ' ', trim($s)) ?? '';
    $s = preg_replace('/^[=+\-@\t\r]+/u', '', $s) ?? '';
    return mb_substr($s, 0, $max, 'UTF-8');
}

function log_security(string $type, string $detail = ''): void {
    try {
        db()->prepare('INSERT INTO security_logs (event_type, detail, ip, user_agent) VALUES (?,?,?,?)')
            ->execute([$type, mb_substr($detail, 0, 500), client_ip(), substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)]);
    } catch (Throwable $e) { /* ไม่ให้ log ล้มระบบ */ }
}

function rate_limit(string $action, int $max, int $windowSec): bool {
    $st = db()->prepare('SELECT COUNT(*) FROM rate_limits WHERE ip=? AND action=? AND created_at > (NOW() - INTERVAL ? SECOND)');
    $st->execute([client_ip(), $action, $windowSec]);
    if ((int)$st->fetchColumn() >= $max) { log_security('rate_limit', $action); return false; }
    db()->prepare('INSERT INTO rate_limits (ip, action) VALUES (?,?)')->execute([client_ip(), $action]);
    if (random_int(1, 50) === 1) db()->exec('DELETE FROM rate_limits WHERE created_at < (NOW() - INTERVAL 1 DAY)');
    return true;
}

/* ====== CSRF ====== */
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_verify(bool $json = false): void {
    $t = $_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($t) || !hash_equals($_SESSION['csrf'] ?? '', $t)) {
        log_security('csrf_fail', $_SERVER['REQUEST_URI'] ?? '');
        http_response_code(419);
        if ($json) { header('Content-Type: application/json'); echo json_encode(['ok' => false, 'msg' => 'CSRF token ไม่ถูกต้อง โปรดรีเฟรชหน้า']); }
        else echo 'CSRF token ไม่ถูกต้อง กรุณากลับไปรีเฟรชหน้าแล้วลองใหม่';
        exit;
    }
}

/* ====== Auth ====== */
function is_admin(): bool {
    if (empty($_SESSION['admin'])) return false;
    if (time() - ($_SESSION['last_act'] ?? 0) > 1800) { session_unset(); return false; }
    if (($_SESSION['ua'] ?? '') !== hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '')) { session_unset(); return false; }
    $_SESSION['last_act'] = time();
    return true;
}
function require_admin(bool $json = false): void {
    if (is_admin()) return;
    if ($json) { http_response_code(401); header('Content-Type: application/json'); echo json_encode(['ok' => false, 'msg' => 'หมดเวลาการเข้าสู่ระบบ']); exit; }
    header('Location: login.php'); exit;
}
function require_role_admin(): void {
    if (($_SESSION['admin']['role'] ?? '') !== 'admin') { http_response_code(403); exit('เฉพาะผู้ดูแลระบบ (admin) เท่านั้น'); }
}

/* ====== Utilities ====== */
function fmt_duration(?int $sec): string {
    if ($sec === null) return '-';
    return sprintf('%d ชม. %02d นาที %02d วิ', intdiv($sec, 3600), intdiv($sec % 3600, 60), $sec % 60);
}
function fmt_dt(?string $d): string { return $d ? date('d/m/Y H:i:s', strtotime($d)) : '-'; }
function json_out(array $a, int $code = 200): void {
    http_response_code($code); header('Content-Type: application/json; charset=utf-8');
    echo json_encode($a, JSON_UNESCAPED_UNICODE); exit;
}
function new_ticket(): string {
    do {
        $c = strtoupper(bin2hex(random_bytes(10)));
        $st = db()->prepare('SELECT 1 FROM participants WHERE ticket_code=?'); $st->execute([$c]);
    } while ($st->fetchColumn());
    return $c;
}
function valid_phone(string $p): bool { return (bool)preg_match('/^[0-9+\- ]{9,15}$/', $p); }
